
#include "NUC200Series.h"
#include "hid_transfer.h"
#include "ISP_USER.h"

#define DetectPin   				PA10
