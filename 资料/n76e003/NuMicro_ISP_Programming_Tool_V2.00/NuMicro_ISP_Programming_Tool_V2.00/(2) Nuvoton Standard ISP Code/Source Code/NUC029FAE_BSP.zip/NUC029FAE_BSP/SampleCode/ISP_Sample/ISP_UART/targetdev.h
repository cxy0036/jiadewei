
#include "NUC029FAE.h"

/* rename for uart_transfer.c */
#define UART_T							UART
#define UART_T_IRQHandler		UART_IRQHandler
#define UART_T_IRQn					UART_IRQn
