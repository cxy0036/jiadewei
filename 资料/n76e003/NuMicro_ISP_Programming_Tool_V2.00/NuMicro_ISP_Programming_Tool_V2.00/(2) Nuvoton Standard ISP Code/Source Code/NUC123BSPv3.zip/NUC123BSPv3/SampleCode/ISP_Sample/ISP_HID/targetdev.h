
#include "NUC123.h"
#include "ISP_USER.h"

#define DetectPin   				PB14
