
#include "M451Series.h"
#include "ISP_USER.h"
#include "hid_transfer.h"

#define DetectPin   PB6
