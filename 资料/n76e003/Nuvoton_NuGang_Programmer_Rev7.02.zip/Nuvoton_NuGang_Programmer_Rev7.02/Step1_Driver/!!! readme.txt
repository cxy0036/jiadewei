Note:
  The NuGang Programmer has the USB-to-Serial bridge chip (PL-2303) built nside.
  When connected to host, it will appear as a USB-to-Serial COM port in the
  System\Hardware\Device Manager. Before starting to use this programmer, the user
  needs to install the driver in the host if the PL-2303 driver has never been
  installed in this host. 

  if need, the driver may be updated by downloading the newer revision from the
  web-site of Prolific Tech. Inc.:

     http://www.prolific.com.tw/US/ShowProduct.aspx?pcid=41&showlevel=0017-0037-0041
