/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2015 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

//***********************************************************************************************************
//  Nuvoton Technoledge Corp. 
//  Website: http://www.nuvoton.com
//  E-Mail : MicroC-8bit@nuvoton.com
//  Date   : Sep/1/2015
//***********************************************************************************************************

//***********************************************************************************************************
//  File Function: N76E616 "Automatic Address Recongnition Master" of UART0 demo code
//***********************************************************************************************************

// Automatic Address Recongnition Master Example
// Master will cycle between addressing slave1, slave2 and broadcasting

#include <stdio.h>
#include "N76E616.h"
#include "Version.h"
#include "Typedef.h"
#include "Define.h"
#include "SFR_Macro.h"
#include "Common.h"
#include "Delay.h"

/*
//-------- <<< Use Configuration Wizard in Context Menu >>> ------------------
//
//<e0> System Clock Source Configuration
// <o1> System Clock Source Selection
//      <0=> 2~16MHz    XTAL
//      <1=> 32.768KHz  XTAL
//      <2=> 11.0592MHz Internal
//      <3=> 10KHz      Internal
//      <4=> OSC-In     External
//</e>
//
//<e2> Clock Divider Configuration
//     <o3.0..7>  System Clock Source Devider
//                     <i> Fsys = (System Clock Source) / (2 * Devider)
//                     <1-255>
//</e>
//
//-------- <<< end of configuration section >>> ------------------------------
*/

#define SYS_CLK_EN      1
#define SYS_SEL         2
#define SYS_DIV_EN      1                       //0: Fsys=Fosc, 1: Fsys = Fosc/(2*CKDIV)
#define SYS_DIV         1

#define slave1          0xF0                    //Slave1 given address
#define slave2          0xF3                    //Slave2 given address
#define bcast           0xFF                    //broadcast address
bit BIT_TMP;
UINT8 ch;
//-----------------------------------------------------------------------------------------------------------
void tx_address(UINT8 ch)
{
    set_TB8;                                    //transmit address byte
    clr_TI;
    SBUF = ch;
    while(!TI);
}
//-----------------------------------------------------------------------------------------------------------
void tx_data(UINT8 ch)
{
    clr_TB8;                                    //transmit data byte
    clr_TI;
    SBUF = ch;
    while(!TI);
}

//-----------------------------------------------------------------------------------------------------------
/**
 * FUNCTION_PURPOSE: Main function 
 */
void main (void)
{
    /* Note
       MCU power on system clock is HIRC (11.0529MHz), so Fsys = 11.0592MHz
    */
    
    Set_All_GPIO_Quasi_Mode();
    
    #if SYS_CLK_EN == 1
        #if   SYS_SEL == 0
            System_Clock_Select(E_HXTEN);   //Fosc = 2~16MHz XTAL
        #elif SYS_SEL == 1
            System_Clock_Select(E_LXTEN);   //Fosc = 32.768KHz XTAL
        #elif SYS_SEL == 2
            System_Clock_Select(E_HIRCEN);  //Fosc = 11.0592MHz Internal RC
        #elif SYS_SEL == 3
            System_Clock_Select(E_LIRCEN);  //Fosc = 10KHz Internal RC
        #elif SYS_SEL == 4
            System_Clock_Select(E_OSCEN);   //Fosc = OSC-In External OSC
        #endif
    #endif
    
    #if SYS_DIV_EN == 1
        CKDIV = SYS_DIV;                        //Fsys = Fosc / (2* CLKDIV) = Fcpu
    #endif
    
    TH1 =  0xFA;                                //9600 bps @11.0592MHz
    TL1 =  0xFA;
    TMOD |= 0x20;

    SCON = 0xD0;                                //configure UART0 for 9-bit mode + REN
    set_TR1;

    if(P10 == 0)
    {
        tx_address(slave1);
        tx_data(slave1);
    }

    if(P11 == 0)
    {
        tx_address(slave2);
        tx_data(slave2);
    }

    if(P12 == 0)
    {
        tx_address(bcast);
        tx_data(0xAA);
    }


    while(1);
}
//-----------------------------------------------------------------------------------------------------------
