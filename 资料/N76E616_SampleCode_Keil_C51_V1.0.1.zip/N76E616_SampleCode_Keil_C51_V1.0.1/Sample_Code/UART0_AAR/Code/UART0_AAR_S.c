/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2015 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

//***********************************************************************************************************
//  Nuvoton Technoledge Corp. 
//  Website: http://www.nuvoton.com
//  E-Mail : MicroC-8bit@nuvoton.com
//  Date   : Sep/1/2015
//***********************************************************************************************************

//***********************************************************************************************************
//  File Function: N76E616 UART-0 AAR demo code
//***********************************************************************************************************

// Automatic Address Recongnition Slave Example
// Slave will wake-up from idle mode whenever address
// matches and output data to port P1
// change slave address in main function for slave

#include <stdio.h>
#include "N76E616.h"
#include "Version.h"
#include "Typedef.h"
#include "Define.h"
#include "SFR_Macro.h"
#include "Common.h"
#include "Delay.h"

/*
//-------- <<< Use Configuration Wizard in Context Menu >>> ------------------
//
//<e0> System Clock Source Configuration
// <o1> System Clock Source Selection
//      <0=> 2~16MHz    XTAL
//      <1=> 32.768KHz  XTAL
//      <2=> 11.0592MHz Internal
//      <3=> 10KHz      Internal
//      <4=> OSC-In     External
//</e>
//
//<e2> Clock Divider Configuration
//     <o3.0..7>  System Clock Source Devider
//                     <i> Fsys = (System Clock Source) / (2 * Devider)
//                     <1-255>
//</e>
//
//-------- <<< end of configuration section >>> ------------------------------
*/

#define SYS_CLK_EN      1
#define SYS_SEL         2
#define SYS_DIV_EN      1                   //0: Fsys=Fosc, 1: Fsys = Fosc/(2*CKDIV)
#define SYS_DIV         1

#define slave1 0xF1                     //Slave1 address and mask
#define smask1 0xFA
//S1 addr = 11110x0x

#define slave2 0xF3                     //Slave2 address and mask
#define smask2 0xF9
//S2 addr = 11110xx1

#define bcast  0xFF                     //broadcast address
bit BIT_TMP;
UINT8 ch;
//-----------------------------------------------------------------------------------------------------------
void serial_ISR (void) interrupt 4 
{
    if (RI) 
    {                                   /* if reception occur */
        ch = SBUF;                      //read the byte
        clr_RI;

        if(SM2)                         //alternate between address and data
        {
            clr_SM2;                    //change to data mode
        }
        else
        {
            P1 = ch;                    //output data and change to address mode
            set_SM2;
        }
    }
    if(TI)
    {
        clr_TI;                         /* if emission occur */
    }
}

//-----------------------------------------------------------------------------------------------------------
/**
 * FUNCTION_PURPOSE: Main function 
 */
void main (void)
{
    UINT8 i;
    
    /* Note
       MCU power on system clock is HIRC (11.0592MHz), so Fsys = 11.0592MHz
    */
    
    Set_All_GPIO_Quasi_Mode();
    
    #if SYS_CLK_EN == 1
        #if   SYS_SEL == 0
            System_Clock_Select(E_HXTEN);   //Fosc = 2~16MHz XTAL
        #elif SYS_SEL == 1
            System_Clock_Select(E_LXTEN);   //Fosc = 32.768KHz XTAL
        #elif SYS_SEL == 2
            System_Clock_Select(E_HIRCEN);  //Fosc = 11.0592MHz Internal RC
        #elif SYS_SEL == 3
            System_Clock_Select(E_LIRCEN);  //Fosc = 10KHz Internal RC
        #elif SYS_SEL == 4
            System_Clock_Select(E_OSCEN);   //Fosc = OSC-In External OSC
        #endif
    #endif
    
    #if SYS_DIV_EN == 1
        CKDIV = SYS_DIV;                    //Fsys = Fosc / (2* CLKDIV) = Fcpu
    #endif
    
    Set_All_GPIO_Quasi_Mode();              //Set all GPIO are Quasi Mode
    
    for(i=0;i<3;i++)
    {
        P0 = 0x55;
        Timer0_Delay1ms(200);
        P0 = 0xFF;
        Timer0_Delay1ms(200);
    }
    TH1 =  0xFD;                        //9600 bps @11.0592MHz
    TL1 =  0xFD;
    TMOD |= 0x20;

    PCON &= 0xBF;                       //force SMOD0 = 0
    SCON = 0xF0;                        //configure UART0 for 9-bit mode + REN + AAR

#if 1
    SADDR = slave1; //F1                //set slave1 address
    SADEN = smask1; //FA
#else
    SADDR = slave2; //F3                //set slave2 address
    SADEN = smask2; //F9
#endif

    set_SM2;
    IE = 0x90;                          //enable serial interrupt + EA
    set_TR1;

    while(1)
    {
        if(SM2)
        {
            PCON |= 0x01;               //if waiting for address then go to sleep
        }
    }
}
//-----------------------------------------------------------------------------------------------------------
