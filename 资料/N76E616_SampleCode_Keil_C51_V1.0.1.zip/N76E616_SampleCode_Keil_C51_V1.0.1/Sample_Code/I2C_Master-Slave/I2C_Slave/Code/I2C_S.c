/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2015 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

//***********************************************************************************************************
//  Nuvoton Technoledge Corp. 
//  Website: http://www.nuvoton.com
//  E-Mail : MicroC-8bit@nuvoton.com
//  Date   : Sep/1/2015
//***********************************************************************************************************

//***********************************************************************************************************
//  File Function: N76E616 I2C Slave demo code
//***********************************************************************************************************

#include <stdio.h>
#include "N76E616.h"
#include "Version.h"
#include "Typedef.h"
#include "Define.h"
#include "SFR_Macro.h"
#include "Common.h"
#include "Delay.h"

//***********************************************************************************************************
//  N76E616-series I2C slave mode demo code, the Slave address = 0xA4
//
//   ____________            _____________ 
//  |            |   SDA    |             |
//  |            |<-------->|             |
//  |            |          |             |
//  | N76E616(M) |          | N76E616 (S) |
//  |(I2C_Master)|          | (I2C_Slave) |
//  |            |   SCL    |             |
//  |            |--------->|             |
//  |____________|          |_____________|
//
//  The protocol of I2C is same the "24LC64"
//***********************************************************************************************************

/*
//-------- <<< Use Configuration Wizard in Context Menu >>> ------------
//
////<e0> System Clock Source Configuration
// <o1> System Clock Source Selection
//      <0=> 2~16MHz    XTAL
//      <1=> 32.768KHz  XTAL
//      <2=> 11.0592MHz Internal
//      <3=> 10KHz      Internal
//      <4=> OSC-In     External
//</e>
//
//<e2> Clock Divider Configuration
//     <o3.0..7>  System Clock Source Devider <1-255>
//                     <i> Fsys = (System Clock Source) / (2 * Devider)
//</e>
//
// <o4> I2C Clock Rate Selection (11.0592MHz System Clock)
//                  <26=> 100kbps
//                  <6=> 400kbps
//-------- <<< end of configuration section >>> ------------------------------
*/

#define SYS_CLK_EN              1
#define SYS_SEL                 2
#define SYS_DIV_EN              0                   //0: Fsys=Fosc, 1: Fsys = Fosc/(2*CKDIV)
#define SYS_DIV                 27
#define I2C_CLOCK               6

#define EEPROM_SLA              0xA4

UINT8 data_received[34], data_num = 0;
bit   BIT_TMP;
//========================================================================================================
void I2C_ISR(void) interrupt 6
{
    switch (I2STAT)
    {
        case 0x00:
            STO = 1;
            break;

        case 0x60:
            AA = 1;
            //P3 = 0x60;
            break;
				
        case 0x68:
						P02 = 0;
            while(1);
            break;

        case 0x80:
            //P3 = 0x80;
            data_received[data_num] = I2DAT;
            data_num++;

            if (data_num == 34)
                AA = 0;
            else
                AA = 1;
            break;

        case 0x88:
            //P3 = 0x88;
            data_received[data_num] = I2DAT;
            data_num = 0;
            AA = 1;
            break;

        case 0xA0:
            //P3 = 0xA0;
            AA = 1;
            break;

        case 0xA8:
            //P3 = 0xA0;
            I2DAT = data_received[data_num];
            data_num++;
            AA = 1;
            break;
        
        case 0xB8:
            //P3 = 0xB8;
            I2DAT = data_received[data_num];
            data_num++;
            AA = 1;
            break;

        case 0xC0:
            AA = 1;
            break; 

        case 0xC8:
            //P3 = 0xC8;
            AA = 1;
            break;        
    }

    SI = 0;
    while(STO);
}

//========================================================================================================
void Init_I2C(void)
{
    clr_P2M1_4;                             //set SCL (P24) is Quasi mode
    clr_P2M2_4;

    clr_P2M1_3;                             //set SDA (P23) is Quasi mode
    clr_P2M2_3;

    SDA = 1;                                //set SDA and SCL pins high
    SCL = 1;
    
//    set_P0SR_6;                             //set SCL (P06) is  Schmitt triggered input select.
//    set_P2SR_4;                             //set SCL (P24) is  Schmitt triggered input select.
    
    set_EI2C;                               //enable I2C interrupt by setting IE1 bit 0
    set_EA;

    I2ADDR = EEPROM_SLA;                    //define own slave address
    set_I2CEN;                              //enable I2C circuit
    set_AA;
}

//========================================================================================================
void main(void)
{
    /* Note
       MCU power on system clock is HIRC (11.0592MHz), so Fsys = 11.0592MHz
    */
    
    Set_All_GPIO_Quasi_Mode();

    #if DEBUG_PORT == 0
        InitialUART0_Timer1_Type1(9600);            /* 9600 Baud Rate*/
    #elif DEBUG_PORT == 1
        InitialUART1_Timer3(9600);                  /* 9600 Baud Rate*/
    #endif

    Show_FW_Version_Number_To_PC();

    printf ("\n*====================================================================");
    printf ("\n*    Name: N76E616 I2C Slave ModeDemo Code. ");
    printf ("\n*  ____________            _____________     ");
    printf ("\n* |            |   SDA    |             |    ");
    printf ("\n* |            |<-------->|             |    ");
    printf ("\n* |            |          |             |    ");
    printf ("\n* | N76E616(M) |          |  N76E616(S) |    ");
    printf ("\n* |(I2C_Master)|          | (I2C_Slave) |    ");
    printf ("\n* |            |   SCL    |             |    ");
    printf ("\n* |            |--------->|             |    ");
    printf ("\n* |____________|          |_____________|    ");
    printf ("\n* The protocol of I2C is same the 24LC64     ");    
    printf ("\n*==================================================================\n");
        
    /* Change system closk source */
    #if SYS_CLK_EN == 1
        #if   SYS_SEL == 0
            System_Clock_Select(E_HXTEN);   //Fosc = 2~16MHz XTAL
        #elif SYS_SEL == 1
            System_Clock_Select(E_LXTEN);   //Fosc = 32.768KHz XTAL
        #elif SYS_SEL == 2
            System_Clock_Select(E_HIRCEN);  //Fosc = 11.0592MHz Internal RC
        #elif SYS_SEL == 3
            System_Clock_Select(E_LIRCEN);  //Fosc = 10KHz Internal RC
        #elif SYS_SEL == 4
            System_Clock_Select(E_OSCEN);   //Fosc = OSC-In External OSC
        #endif
    #endif
    
    #if SYS_DIV_EN == 1
        CKDIV = SYS_DIV;                        //Fsys = Fosc / (2* CLKDIV) = Fcpu
    #endif
    
    /* Initial I2C function */
    Init_I2C();                                 //initial I2C circuit

    while (1);
/* =================== */
}

