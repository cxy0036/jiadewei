/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2015 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

//***********************************************************************************************************
//  Nuvoton Technoledge Corp. 
//  Website: http://www.nuvoton.com
//  E-Mail : MicroC-8bit@nuvoton.com
//  Date   : Sep/1/2015
//***********************************************************************************************************

//***********************************************************************************************************
//  File Function: N76E616 ADC demo code
//***********************************************************************************************************

#include <stdio.h>
#include "N76E616.h"
#include "Version.h"
#include "Typedef.h"
#include "Define.h"
#include "SFR_Macro.h"
#include "Common.h"
#include "Delay.h"

/*
//-------- <<< Use Configuration Wizard in Context Menu >>> ------------------
//
//<e0> System Clock Source Configuration
// <o1> System Clock Source Selection
//      <0=> 2~16MHz    XTAL
//      <1=> 32.768KHz  XTAL
//      <2=> 11.0592MHz Internal
//      <3=> 10KHz      Internal
//      <4=> OSC-In     External
//</e>
//
//<e2> Clock Divider Configuration
//     <o3.0..7>  System Clock Source Devider <1-255:1>
//                     <i> Fsys = (System Clock Source) / (2 * Devider)
//</e>
//
//<h> ADC Option
// <o4.0..3> ADC Pin Selection 
//      <0=> AIN0 (P00) <1=> AIN1 (P01) <2=> AIN2 (P02) <3=> AIN3 (P03)
//      <4=> AIN4 (P04) <5=> AIN5 (P05) <6=> AIN6 (P06) <7=> AIN7 (P07)
//      <8=> AIN8 (P26) <9=> AIN9 (P20) <10=> Band-Gap
//
// <o5.0..2> ADC Divider Selection 
//      <0=> Fsys/1  <1=> Fsys/2   <2=> Fsys/4   <3=> Fsys/8
//      <4=> Fsys/16 <5=> Fsys/32  <6=> Fsys/64  <7=> Fsys/128
//
//</h>
//
//-------- <<< end of configuration section >>> ------------------------------
*/

#define SYS_CLK_EN      0
#define SYS_SEL         2
#define SYS_DIV_EN      0                   //0: Fsys=Fosc, 1: Fsys = Fosc/(2*CKDIV)
#define SYS_DIV         1

#define ADC_PIN         0
#define ADC_DIV         2

bit BIT_TMP;
/******************************************************************************
 * FUNCTION_PURPOSE: ADC interrupt Service Routine
 ******************************************************************************/
void ADC_ISR (void) interrupt 11
{
    clr_ADCF;                               //clear ADC interrupt flag
}
/******************************************************************************
 * FUNCTION_PURPOSE: ADC Pin Select
 ******************************************************************************/
void ADC_Pin_Select (void)
{
    #if   ADC_PIN == 0                      //P0.0
          ADCCON0 = 0x00;                   //select ADC pin
          set_P0M1_0;                       //set ADC pin is input only mode
          clr_P0M2_0;
          set_P00DIDS;                      //disable digital connection
    #elif ADC_PIN == 1                      //P0.1
          ADCCON0 = 0x01;                   //select ADC pin
          set_P0M1_1;                       //set ADC pin is input only mode
          clr_P0M2_1;
          set_P01DIDS;                      //disable digital connection
    #elif ADC_PIN == 2                      //P0.2
          ADCCON0 = 0x02;                   //select ADC pin
          set_P0M1_2;                       //set ADC pin is input only mode
          clr_P0M2_2;
          set_P02DIDS;                      //disable digital connection
    #elif ADC_PIN == 3                      //P0.3
          ADCCON0 = 0x03;                   //select ADC pin
          set_P0M1_3;                       //set ADC pin is input only mode
          clr_P0M2_3;
          set_P03DIDS;                      //disable digital connection
    #elif ADC_PIN == 4                      //P0.4
          ADCCON0 = 0x04;                   //select ADC pin
          set_P0M1_4;                       //set ADC pin is input only mode
          clr_P0M2_4;
          set_P04DIDS;                      //disable digital connection
    #elif ADC_PIN == 5                      //P0.5
          ADCCON0 = 0x05;                   //select ADC pin
          set_P0M1_5;                       //set ADC pin is input only mode
          clr_P0M2_5;
          set_P05DIDS;                      //disable digital connection
    #elif ADC_PIN == 6                      //P0.6
          ADCCON0 = 0x06;                   //select ADC pin
          set_P0M1_6;                       //set ADC pin is input only mode
          clr_P0M2_6;
          set_P06DIDS;                      //disable digital connection
    #elif ADC_PIN == 7                      //P0.7
          ADCCON0 = 0x07;                   //select ADC pin
          set_P0M1_7;                       //set ADC pin is input only mode
          clr_P0M2_7;
          set_P07DIDS;                      //disable digital connection
    #elif ADC_PIN == 8                      //P2.6
          ADCCON0 = 0x08;                   //select ADC pin
          set_P2M1_6;                       //set ADC pin is input only mode
          clr_P2M2_6;
          set_P26DIDS;                      //disable digital connection
    #elif ADC_PIN == 9                      //P2.0
          ADCCON0 = 0x09;                   //select ADC pin
          set_P2M1_0;                       //set ADC pin is input only mode
          clr_P2M2_0;
          set_P20DIDS;                      //disable digital connection
    #else
          ADCCON0 |= 0x0F;                  //band-gap 1.25V
    #endif
}
/******************************************************************************
 * FUNCTION_PURPOSE: ADC Clock Divider Select
 ******************************************************************************/
void ADC_DIV_Select (void)
{
    #if   ADC_DIV == 0
          clr_ADCDIV2;
          clr_ADCDIV1;
          clr_ADCDIV0;
    #elif ADC_DIV == 1
          clr_ADCDIV2;
          clr_ADCDIV1;
          set_ADCDIV0;
    #elif ADC_DIV == 2      //Default
          clr_ADCDIV2;
          set_ADCDIV1;
          clr_ADCDIV0;
    #elif ADC_DIV == 3
          clr_ADCDIV2;
          set_ADCDIV1;
          set_ADCDIV0;
    #elif ADC_DIV == 4
          clr_ADCDIV2;
          clr_ADCDIV1;
          set_ADCDIV0;
    #elif ADC_DIV == 5
          set_ADCDIV2;
          clr_ADCDIV1;
          clr_ADCDIV0;
    #elif ADC_DIV == 6
          set_ADCDIV2;
          clr_ADCDIV1;
          set_ADCDIV0;
    #elif ADC_DIV == 7
          set_ADCDIV2;
          set_ADCDIV1;
          clr_ADCDIV0;
    #elif ADC_DIV == 8
          set_ADCDIV2;
          set_ADCDIV1;
          set_ADCDIV0;
    #endif
}
/******************************************************************************
 * FUNCTION_PURPOSE: ADC Initial
 ******************************************************************************/
void ADC_Initial (void)
{
    set_ADCEN;
    ADC_Pin_Select();                           //Select ADC Pin
    ADC_DIV_Select();                           //Set ADC Clock Divider
}

/******************************************************************************
The main C function.  Program execution starts
here after stack initialization.
******************************************************************************/
void main (void) 
{
    UINT8 i;
    
    /* Note
       MCU power on system clock is HIRC (11.0592MHz), so Fsys = 11.0592MHz
    */
    
    Set_All_GPIO_Quasi_Mode();

    #if DEBUG_PORT == 0
        InitialUART0_Timer1_Type1(9600);            /* 9600 Baud Rate*/
    #elif DEBUG_PORT == 1
        InitialUART1_Timer3(9600);                  /* 9600 Baud Rate*/
    #endif

    Show_FW_Version_Number_To_PC();

    printf ("\n*===================================================================");
    printf ("\n*  Name: N76E616 ADC Demo Code.");
    printf ("\n*===================================================================\n");
    
    /* Change system closk source */
    #if SYS_CLK_EN == 1
        #if   SYS_SEL == 0
            System_Clock_Select(E_HXTEN);   //Fosc = 2~16MHz XTAL
        #elif SYS_SEL == 1
            System_Clock_Select(E_LXTEN);   //Fosc = 32.768KHz XTAL
        #elif SYS_SEL == 2
            System_Clock_Select(E_HIRCEN);  //Fosc = 11.0592MHz Internal RC
        #elif SYS_SEL == 3
            System_Clock_Select(E_LIRCEN);  //Fosc = 10KHz Internal RC
        #elif SYS_SEL == 4
            System_Clock_Select(E_OSCEN);   //Fosc = OSC-In External OSC
        #endif
    #endif
    
    #if SYS_DIV_EN == 1
        CKDIV = SYS_DIV;                        //Fsys = Fosc / (2* CLKDIV) = Fcpu
    #endif
    
    for(i=0;i<3;i++)
    {
        P02 = 0;
        Timer0_Delay1ms(200);
        P02 = 1;
        Timer0_Delay1ms(200);
    }

    ADC_Initial();
    
    while(1)
    {
        clr_ADCF;
        set_ADCS;                               //Trigger ADC start conversion
        #if 0                                   //Polling
            while(ADCF == 0);
            ADCF = 0;
        #else                                   //Interrupt
            EADC = 1;
            EA = 1;
            set_IDLE;                           //Enter idle mode
        #endif
        printf ("\n*  ADC conver value = %d",(UINT16)ADCRH);
        Timer0_Delay1ms(100);
    }
}


