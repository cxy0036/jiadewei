/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2015 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

//***********************************************************************************************************
//  Nuvoton Technoledge Corp. 
//  Website: http://www.nuvoton.com
//  E-Mail : MicroC-8bit@nuvoton.com
//  Date   : Sep/1/2015
//***********************************************************************************************************

//***********************************************************************************************************
//  File Function: N76E616 UART-0 Mode3 demo code
//***********************************************************************************************************

#include <stdio.h>
#include "N76E616.h"
#include "Version.h"
#include "Typedef.h"
#include "Define.h"
#include "SFR_Macro.h"
#include "Common.h"
#include "Delay.h"

/*
//-------- <<< Use Configuration Wizard in Context Menu >>> ------------------
//
//<e0> System Clock Source Configuration
// <o1> System Clock Source Selection
//      <0=> 2~16MHz    XTAL
//      <1=> 32.768KHz  XTAL
//      <2=> 11.0592MHz Internal
//      <3=> 10KHz      Internal
//      <4=> OSC-In     External
//</e>
//
//<e2> Clock Divider Configuration
//     <o3.0..7>  System Clock Source Devider
//                     <i> Fsys = (System Clock Source) / (2 * Devider)
//                     <1-255>
//</e>
//
//-------- <<< end of configuration section >>> ------------------------------
*/

#define SYS_CLK_EN      1
#define SYS_SEL         2
#define SYS_DIV_EN      0                   //0: Fsys=Fosc, 1: Fsys = Fosc/(2*CKDIV)
#define SYS_DIV         1
#define BUFFER_SIZE     128

UINT8  xdata UART_BUFFER[BUFFER_SIZE];
UINT16 u16CNT=0,u16CNT1=0;
bit    BIT_TMP;
/**
 * FUNCTION_PURPOSE: serial interrupt, echo received data.
 * FUNCTION_INPUTS: P3.0(RXD) serial input
 * FUNCTION_OUTPUTS: P3.1(TXD) serial output
 */
void serial_1_IT(void) interrupt 15 
{
    if (RI_1) 
    {                                           /* if reception occur */
        clr_RI_1;                               /* clear reception flag for next reception */
        UART_BUFFER[u16CNT] = SBUF_1;
        u16CNT ++;
    }
    if(TI_1)
    {
        clr_TI_1;                               /* if emission occur */
    }
}
/************************************************************************************************************
*    Main function 
************************************************************************************************************/
void main (void)
{
    /* Note
       MCU power on system clock is HIRC (11.0592MHz), so Fsys = 11.0592MHz
    */
    
    UINT16 i=0;
    
    Set_All_GPIO_Quasi_Mode();
    
    #if SYS_CLK_EN == 1
        #if   SYS_SEL == 0
            System_Clock_Select(E_HXTEN);   //Fosc = 2~16MHz XTAL
        #elif SYS_SEL == 1
            System_Clock_Select(E_LXTEN);   //Fosc = 32.768KHz XTAL
        #elif SYS_SEL == 2
            System_Clock_Select(E_HIRCEN);  //Fosc = 11.0592MHz Internal RC
        #elif SYS_SEL == 3
            System_Clock_Select(E_LIRCEN);  //Fosc = 10KHz Internal RC
        #elif SYS_SEL == 4
            System_Clock_Select(E_OSCEN);   //Fosc = OSC-In External OSC
        #endif
    #endif
    
    #if SYS_DIV_EN == 1
        CKDIV = SYS_DIV;                        //Fsys = Fosc / (2* CLKDIV) = Fcpu
    #endif
    
    Set_All_GPIO_Quasi_Mode();                  //Set all GPIO are Quasi Mode
    
    #if DEBUG_PORT == 0
        InitialUART0_Timer1_Type1(9600);            /* 9600 Baud Rate*/
    #elif DEBUG_PORT == 1
        InitialUART1_Timer3(9600);                  /* 9600 Baud Rate*/
    #endif

    SCON_1 = 0xD2;
    
    printf ("\n*========================================================*");
    printf ("\n*          N76E616 UART0 Mode 3 Demo, TB8 as Stop bit2  *");
    printf ("\n*             1. Please send 128B to N76E616            *");
    printf ("\n*             2. N76E616 will return the 128B to PC     *");
    printf ("\n*========================================================*\n");

    set_ES_1;                                 //enable UART1 interrupt
    set_EA;                                   //enable global interrupt
    clr_TB8_1;
    
    while(1)
    {
        if(u16CNT == BUFFER_SIZE)
        {
            clr_EA;
            for(i=0;i<u16CNT;i++)
            {
                SBUF_1 = UART_BUFFER[i];
                while(TI_1==0);
            }
            set_EA;            
            u16CNT = 0;
        }        
    }
}

