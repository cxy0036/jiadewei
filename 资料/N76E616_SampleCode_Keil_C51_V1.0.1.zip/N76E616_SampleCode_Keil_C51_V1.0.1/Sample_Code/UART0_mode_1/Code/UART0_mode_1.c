/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2015 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

//***********************************************************************************************************
//  Nuvoton Technoledge Corp. 
//  Website: http://www.nuvoton.com
//  E-Mail : MicroC-8bit@nuvoton.com
//  Date   : Sep/1/2015
//***********************************************************************************************************

//***********************************************************************************************************
//  File Function: N76E616 UART-0 Mode1 demo code
//***********************************************************************************************************

#include <stdio.h>
#include "N76E616.h"
#include "Version.h"
#include "Typedef.h"
#include "Define.h"
#include "SFR_Macro.h"
#include "Common.h"
#include "Delay.h"

/*
//-------- <<< Use Configuration Wizard in Context Menu >>> ------------------
//
//<e0> System Clock Source Configuration
// <o1> System Clock Source Selection
//      <0=> 2~16MHz    XTAL
//      <1=> 32.768KHz  XTAL
//      <2=> 11.0592MHz Internal
//      <3=> 10KHz      Internal
//      <4=> OSC-In     External
//</e>
//
//<e2> Clock Divider Configuration
//     <o3.0..7>  System Clock Source Devider  <1-255>
//                     <i> Fsys = (System Clock Source) / (2 * Devider)
//</e>
//
//-------- <<< end of configuration section >>> ------------------------------
*/

#define SYS_CLK_EN      0
#define SYS_SEL         2
#define SYS_DIV_EN      0                   //0: Fsys=Fosc, 1: Fsys = Fosc/(2*CKDIV)
#define SYS_DIV         1

#define u8Receive_Buffer_Size 4 // Receive Buffer Size. (0 - 255)
BIT Receive_Get = 0,Transmit_Busy;
UINT8 u8Receive_Buffer_Index = 0;
UINT8 xdata Receive_Buffer[u8Receive_Buffer_Size] = {0}; // Receive_Buffer.
bit BIT_TMP;
/******************************************************************************
 * FUNCTION_PURPOSE: Serial interrupt, echo received data.
 * FUNCTION_INPUTS : P2.0(RXD) serial input
 * FUNCTION_OUTPUTS: P0.3(TXD) serial output
 ******************************************************************************/
void Serial0_ISR (void) interrupt 4 
{
    if (RI == 1)
    {
        if (Receive_Get == 0)                   // If Receive_Buffer Not Full.
        {
            Receive_Buffer[u8Receive_Buffer_Index] = SBUF;
            u8Receive_Buffer_Index++;
            
            if (u8Receive_Buffer_Index == u8Receive_Buffer_Size)
            {
                Receive_Get = 1;
            }
        }
        
        clr_RI;                                 // Clear RI (Receive Interrupt).
    }
    if (TI == 1)
    {
        Transmit_Busy = 0;                      // Mark Transmit Not Busy.
        clr_TI;                                 // Clear TI (Transmit Interrupt).
    }      
}


/*******************************************************************************
 * FUNCTION_PURPOSE: Main function 
 ******************************************************************************/
void main (void)
{
    /* Note
       MCU power on system clock is HIRC (11.0592MHz), so Fsys = 11.0592MHz
    */
    
    Set_All_GPIO_Quasi_Mode();                 //Set all GPIO are Quasi Mode
    
    #if DEBUG_PORT == 0
        InitialUART0_Timer1_Type1(9600);            /* 9600 Baud Rate*/
    #elif DEBUG_PORT == 1
        InitialUART1_Timer3(9600);                  /* 9600 Baud Rate*/
    #endif

    //InitialUART0_Timer1_Type1(9600);            //UART0 Baudrate initial,T1M=0,SMOD=0
    //InitialUART0_Timer1_Type2(57600);           //UART0 Baudrate initial,T1M=0,SMOD=1
    //InitialUART0_Timer1_Type3(345600);          //UART0 Baudrate initial,T1M=1,SMOD=0
    //InitialUART0_Timer1_Type4(115200);          //UART0 Baudrate initial,T1M=1,SMOD=1
    //InitialUART0_Timer3_Type5(345600);          //UART0 Baudrate initial,SMOD=0, Prescale=0
    //InitialUART0_Timer3_Type6(691200);          //UART0 Baudrate initial,SMOD=1, Prescale=0
    //InitialUART0_Timer3_Type6(9600);            //UART0 Baudrate initial,SMOD=1, Prescale=0

  /* Change system closk source */  
  #if SYS_CLK_EN == 1
        #if   SYS_SEL == 0
            System_Clock_Select(E_HXTEN);   //Fosc = 2~16MHz XTAL
        #elif SYS_SEL == 1
            System_Clock_Select(E_LXTEN);   //Fosc = 32.768KHz XTAL
        #elif SYS_SEL == 2
            System_Clock_Select(E_HIRCEN);  //Fosc = 11.0592MHz Internal RC
        #elif SYS_SEL == 3
            System_Clock_Select(E_LIRCEN);  //Fosc = 10KHz Internal RC
        #elif SYS_SEL == 4
            System_Clock_Select(E_OSCEN);   //Fosc = OSC-In External OSC
        #endif
  #endif
    
    #if SYS_DIV_EN == 1
        CKDIV = SYS_DIV;                    //Fsys = Fosc / (2* CLKDIV) = Fcpu
    #endif

#if 1
    /* Use this function to check the baudrate */
    while(1)
        Send_Data_To_UART1(0x55);
#else
    {
        UINT8 i;
        while(1)
        {
            /* Get the PC data to Buffer */
            u8Receive_Buffer_Index = 0;
            IE = 0x90;                                  //EA=1, ES=1, UART interrupt and global interrupt enable
            while(Receive_Get == 0);                    //waiting the PC data
            Receive_Get = 0;
            
            /* Send the Buffer data to PC */
            IE = 0;                                     //disable interrupt
            for(i=0;i<u8Receive_Buffer_Size;i++)
            {
                //P2 = Receive_Buffer[i];                 //show receive data to Port2
                Send_Data_To_UART0(Receive_Buffer[i]);     //show receive data to PC
                //Delay1ms(20);
            }
        }
    }
#endif
}

