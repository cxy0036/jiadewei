/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2015 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

//***********************************************************************************************************
//  Nuvoton Technoledge Corp. 
//  Website: http://www.nuvoton.com
//  E-Mail : MicroC-8bit@nuvoton.com
//  Date   : Sep/1/2015
//***********************************************************************************************************

//***********************************************************************************************************
//  File Function: N76E616 Timer0/1 Mode0 demo code
//***********************************************************************************************************

#include <stdio.h>
#include "Timer01.h"
#include "N76E616.h"
#include "Version.h"
#include "Typedef.h"
#include "Define.h"
#include "SFR_Macro.h"
#include "Common.h"
#include "Delay.h"

/*===========================================================================================================
 * Before using this demo code, please set DEMO in "TImer01.h" to decide which *.c is used for different 
 * timer modes.
 *
 * This file set up Timer 0 and 1 in mode 0 or 1. The clock divider, clock gating, timer/counter mode   
 * are all configured by configuration wizard. P1.0 and P1.1 toggles each Timer 0 and Timer 1 interrupt
 * respectively. 
 *===========================================================================================================

/*
//-------- <<< Use Configuration Wizard in Context Menu >>> ------------------
//
////<e0> System Clock Source Configuration
// <o1> System Clock Source Selection
//      <0=> 2~16MHz    XTAL
//      <1=> 32.768KHz  XTAL
//      <2=> 11.0592MHz Internal
//      <3=> 10KHz      Internal
//      <4=> OSC-In     External
//</e>
//
//<e2> Clock Divider Configuration
//     <o3.0..7>  System Clock Source Devider <1-255>
//                     <i> Fsys = (System Clock Source) / (2 * Devider)
//</e>
//
// <o4.2> Timer/Counter 0 Select
//     <0=> Timer                       <1=> Counter
// <o4.6> Timer/Counter 1 Select
//     <0=> Timer                       <1=> Counter
// <o4.0..1> Timer 0 Mode Select
//     <0=> (0) 13-bit mode
// <o4.4..5> Timer 1 Mode Select
//     <0=> (0) 13-bit mode
// <q4.3> Timer 0 Clock Hardware Gating
// <q4.7> Timer 1 Clock Hardware Gating
//
//-------- <<< end of configuration section >>> ------------------------------
*/

#define SYS_CLK_EN      1
#define SYS_SEL         2
#define SYS_DIV_EN      0                   //0: Fsys=Fosc, 1: Fsys = Fosc/(2*CKDIV)
#define SYS_DIV         1
#define TIMER_MODE      0x00 

#define TH0_INIT        5000                //every 5000 pulse(about 5.425ms@HIRC11.0592MHz) will generate an interrupt and P0.2 inversely toggle
#define TL0_INIT        5000
#define TH1_INIT        5000                //every 5000 pulse(about 5.425ms@HIRC11.0592MHz) will generate an interrupt and P0.3 inversely toggle
#define TL1_INIT        5000

bit BIT_TMP;
UINT8 u8TH0_Tmp,u8TL0_Tmp,u8TH1_Tmp,u8TL1_Tmp;

/************************************************************************************************************
*    TIMER 0 interrupt subroutine
************************************************************************************************************/
void Timer0_ISR (void) interrupt 1          //interrupt address is 0x000B
{
    TH0 = u8TH0_Tmp;
    TL0 = u8TL0_Tmp;    
    
    P02 = ~P02;                             //P0.2 toggle when interrupt
}
/************************************************************************************************************
*    TIMER 1 interrupt subroutine
************************************************************************************************************/
void Timer1_ISR (void) interrupt 3          //interrupt address is 0x001B
{
    TH1 = u8TH1_Tmp;
    TL1 = u8TL1_Tmp;   
    
    P03 = ~P03;                             //P0.3 toggle when interrupt
}
/************************************************************************************************************
*    Main function 
************************************************************************************************************/
void main (void)
{
    /* Note
       MCU power on system clock is HIRC (11.0592MHz), so Fsys = 11.0592MHz
    */
    
    Set_All_GPIO_Quasi_Mode();

    #if DEBUG_PORT == 0
        InitialUART0_Timer1_Type1(9600);            /* 9600 Baud Rate*/
    #elif DEBUG_PORT == 1
        InitialUART1_Timer3(9600);                  /* 9600 Baud Rate*/
    #endif

    Show_FW_Version_Number_To_PC();

    printf ("\n*===================================================================");
    printf ("\n*  Name: N76E616 Timer0/1 Mode0 Demo Code.");
    printf ("\n*===================================================================\n");
        
    /* Change system closk source */
    #if SYS_CLK_EN == 1
        #if   SYS_SEL == 0
            System_Clock_Select(E_HXTEN);       //Fosc = 2~16MHz XTAL
        #elif SYS_SEL == 1
            System_Clock_Select(E_LXTEN);       //Fosc = 32.768KHz XTAL
        #elif SYS_SEL == 2
            System_Clock_Select(E_HIRCEN);      //Fosc = 11.0592MHz Internal RC
        #elif SYS_SEL == 3
            System_Clock_Select(E_LIRCEN);      //Fosc = 10KHz Internal RC
        #elif SYS_SEL == 4
            System_Clock_Select(E_OSCEN);       //Fosc = OSC-In External OSC
        #endif
    #endif
    
    #if SYS_DIV_EN == 1
        CKDIV = SYS_DIV;                        //Fsys = Fosc / (2* CLKDIV) = Fcpu
    #endif
    
    TMOD = TIMER_MODE;                          //Timer 0 and Timer 1 mode configuration

    u8TH0_Tmp = (8192-TH0_INIT)/32;
    u8TL0_Tmp = (8192-TL0_INIT)%32;    
    u8TH1_Tmp = (8192-TH1_INIT)/32;
    u8TL1_Tmp = (8192-TL1_INIT)%32;
    
    clr_T0M;
    clr_T1M;
    
    TH0 = u8TH0_Tmp;
    TL0 = u8TL0_Tmp;
    TH1 = u8TH1_Tmp;
    TL1 = u8TL1_Tmp;
    
    set_ET0;                                    //enable Timer0 interrupt
    set_ET1;                                    //enable Timer1 interrupt
    set_EA;                                     //enable interrupts
    set_TR0;                                    //Timer0 run
    set_TR1;                                    //Timer1 run
    while(1);
}

