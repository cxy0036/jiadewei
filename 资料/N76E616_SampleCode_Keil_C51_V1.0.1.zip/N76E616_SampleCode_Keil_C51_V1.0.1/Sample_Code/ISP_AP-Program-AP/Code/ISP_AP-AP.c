/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2015 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

//***********************************************************************************************************
//  Nuvoton Technoledge Corp. 
//  Website: http://www.nuvoton.com
//  E-Mail : MicroC-8bit@nuvoton.com
//  Date   : Sep/1/2015
//***********************************************************************************************************

//***********************************************************************************************************
//  File Function: N76E616 APROM program APROM demo code
//***********************************************************************************************************

#include <stdio.h>
#include "N76E616.h"
#include "Version.h"
#include "Typedef.h"
#include "Define.h"
#include "SFR_Macro.h"
#include "Common.h"
#include "Delay.h"

/*
//-------- <<< Use Configuration Wizard in Context Menu >>> ------------------
//
////<e0> System Clock Source Configuration
// <o1> System Clock Source Selection
//      <0=> 2~16MHz    XTAL
//      <1=> 32.768KHz  XTAL
//      <2=> 11.0592MHz Internal
//      <3=> 10KHz      Internal
//      <4=> OSC-In     External
//</e>
//
//<e2> Clock Divider Configuration
//     <o3.0..7>  System Clock Source Devider <1-255>
//                     <i> Fsys = (System Clock Source) / (2 * Devider)
//</e>
//-------- <<< end of configuration section >>> ------------------------------
*/

#define     SYS_CLK_EN          0
#define     SYS_SEL             2
#define     SYS_DIV_EN          0                   //0: Fsys=Fosc, 1: Fsys = Fosc/(2*CKDIV)
#define     SYS_DIV             1

#define     CID_READ            0x00
#define     DID_READ            0x0C
#define     CFG_READ            0xC0
#define     CFG_ERASE           0xE2

#define     PAGE_ERASE_AP       0x22
#define     BYTE_READ_AP        0x00
#define     BYTE_PROGRAM_AP     0x21

#define     BYTE_PROGRAM_CFG    0xE1
#define     BYTE_READ_CFG       0xC0

#define     PAGE_SIZE           128

#define     DATA_SIZE           4096   
#define     DATA_START_ADDR     0x3800 //(0x4800-0x1000)

#define     ERASE_FAIL          0x70
#define     PROGRAM_FAIL        0x71
#define     IAPFF_FAIL          0x72
#define     IAP_PASS            0x00

#define     DISPLAY_LED         P3

bit BIT_TMP;

//-----------------------------------------------------------------------------------------------------------
void Enable_IAP_Mode(void)
{   
    set_IAPEN;
}
//-----------------------------------------------------------------------------------------------------------
void Disable_IAP_Mode(void)
{   
    clr_IAPEN;
}
//-----------------------------------------------------------------------------------------------------------
void Trigger_IAP(void)
{   
    set_IAPGO;                                  //trigger IAP
    if((CHPCON&SET_BIT6)==SET_BIT6)             //check IAPFF (CHPCON.6)
    {
        DISPLAY_LED = IAPFF_FAIL;
        printf ("\n*  IAPFF = 1.");
        while(1);
    }
}
//-----------------------------------------------------------------------------------------------------------
void ID_Read(UINT8 *pu8CID,UINT8 *pu8DID0,UINT8 *pu8DID1)
{   
    Enable_IAP_Mode();

    //Read CID
    IAPAL = 0x00;
    IAPAH = 0x00;
    IAPCN = CID_READ;
    Trigger_IAP();
    
    *pu8CID = IAPFD;

    //Read DID0
    IAPCN = DID_READ;
    Trigger_IAP();
    *pu8DID0 = IAPFD;

    //Read DID1
    IAPAL ++;
    IAPCN = DID_READ;
    Trigger_IAP();
    *pu8DID1 = IAPFD;

    Disable_IAP_Mode();
}
//-----------------------------------------------------------------------------------------------------------
void CONFIG_Read(UINT8 *pu8CFG0,UINT8 *pu8CFG1,UINT8 *pu8CFG2,UINT8 *pu8CFG3,UINT8 *pu8CFG4)
{   
    Enable_IAP_Mode();

    //Read CONFIG0
    IAPAL = 0x00;
    IAPAH = 0x00;
    IAPCN = CFG_READ;
    Trigger_IAP();
    *pu8CFG0 = IAPFD;

    //Read CONFIG1
    IAPAL ++;
    IAPCN = CFG_READ;
    Trigger_IAP();
    *pu8CFG1 = IAPFD;

    //Read CONFIG2
    IAPAL ++;
    IAPCN = CFG_READ;
    Trigger_IAP();
    *pu8CFG2 = IAPFD;

    //Read CONFIG3
    IAPAL ++;
    IAPCN = CFG_READ;
    Trigger_IAP();
    *pu8CFG3 = IAPFD;

    //Read CONFIG4
    IAPAL ++;
    IAPCN = CFG_READ;
    Trigger_IAP();
    *pu8CFG4 = IAPFD;
    
    Disable_IAP_Mode();
}
//-----------------------------------------------------------------------------------------------------------
void Erase_APROM(void)
{   
    UINT16 u16Count;

    Enable_IAP_Mode();
    
    IAPFD = 0xFF;    
    IAPCN = PAGE_ERASE_AP;
    
    set_APUEN;
    for(u16Count=0x0000;u16Count<DATA_SIZE/PAGE_SIZE;u16Count++)
    {        
        IAPAL = LOBYTE(u16Count*PAGE_SIZE + DATA_START_ADDR);
        IAPAH = HIBYTE(u16Count*PAGE_SIZE + DATA_START_ADDR);
        Trigger_IAP(); 
    } 
    clr_APUEN;
    
    Disable_IAP_Mode();
}
//-----------------------------------------------------------------------------------------------------------
BIT Erase_APROM_Verify(void)
{   
    UINT16 u16Count;
    BIT    Error_Flag = 0;

    Enable_IAP_Mode();
    
    IAPAL = LOBYTE(DATA_START_ADDR);
    IAPAH = HIBYTE(DATA_START_ADDR);
    IAPCN = BYTE_READ_AP;

    for(u16Count=0;u16Count<DATA_SIZE/PAGE_SIZE;u16Count++)
    {   
        IAPFD = 0x00;    
        Trigger_IAP();

        if(IAPFD != 0xFF)
        {
            Error_Flag = 1;
            break;
        }

        IAPAL++;
        if(IAPAL == 0x00)
        {
            IAPAH++;
        }
    } 
    
    Disable_IAP_Mode();
    
    if(Error_Flag == 1)
        return FAIL;
    else
        return PASS;
}
//-----------------------------------------------------------------------------------------------------------
void Program_APROM(void)
{   
    UINT16 u16Count;

    Enable_IAP_Mode();
    
    IAPAL = LOBYTE(DATA_START_ADDR);
    IAPAH = HIBYTE(DATA_START_ADDR);
    IAPFD = 0xFF;
    IAPCN = BYTE_PROGRAM_AP;
    
    set_APUEN;
    for(u16Count=0;u16Count<DATA_SIZE;u16Count++)
    {   
        IAPFD++;     
        Trigger_IAP();
       
        IAPAL++;
        if(IAPAL == 0)
        {
            IAPAH++;
        }
    } 
    clr_APUEN;
    
    Disable_IAP_Mode();
}
//-----------------------------------------------------------------------------------------------------------
BIT Program_APROM_Verify(void)
{   
    UINT16 u16Count;
    UINT8  u8Read_Data;
    BIT    Error_Flag = 0;

    Enable_IAP_Mode();
    
    IAPAL = LOBYTE(DATA_START_ADDR);
    IAPAH = HIBYTE(DATA_START_ADDR);
    IAPCN = BYTE_READ_AP;

    u8Read_Data = 0x00;

    for(u16Count=0;u16Count<DATA_SIZE;u16Count++)
    {   
        Trigger_IAP();
        if(IAPFD != u8Read_Data)
        {
            Error_Flag = 1;
            break;
        }

        IAPAL++;
        if(IAPAL == 0)
        {
            IAPAH++;
        }
        u8Read_Data ++;
    } 

    Disable_IAP_Mode();
     
    if(Error_Flag == 1)
        return FAIL;
    else
        return PASS;
}
//-----------------------------------------------------------------------------------------------------------
void Program_CONFIG(UINT8 u8Address,UINT8 u8Data)
{   
    Enable_IAP_Mode();
    
    IAPAL = u8Address;
    IAPAH = 0x00;
    IAPFD = u8Data;
    IAPCN = BYTE_PROGRAM_CFG;
    
    set_CFUEN;
    Trigger_IAP();
    clr_CFUEN;
    
    Disable_IAP_Mode();
}
//-----------------------------------------------------------------------------------------------------------
void Erase_CONFIG(void)
{   
    Enable_IAP_Mode();
    
    IAPAL = 0x00;
    IAPAH = 0x00;
    IAPFD = 0xFF;
    IAPCN = CFG_ERASE;
    
    set_CFUEN;
    Trigger_IAP();
    clr_CFUEN;
    
    Disable_IAP_Mode();
}
//-----------------------------------------------------------------------------------------------------------
void ID_CONFIG_Read(void)
{
    UINT8 u8CID,u8DID0,u8DID1;
    UINT8 u8CFG0,u8CFG1,u8CFG2,u8CFG3,u8CFG4;
    
    ID_Read(&u8CID,&u8DID0,&u8DID1);
    printf("\nCID  = 0x%X",(UINT16)u8CID);
    printf("\nDID0 = 0x%X",(UINT16)u8DID0);
    printf("\nDID1 = 0x%X",(UINT16)u8DID1);

    CONFIG_Read(&u8CFG0,&u8CFG1,&u8CFG2,&u8CFG3,&u8CFG4);
    printf("\nCFG0 = 0x%X",(UINT16)u8CFG0);
    printf("\nCFG1 = 0x%X",(UINT16)u8CFG1);
    printf("\nCFG2 = 0x%X",(UINT16)u8CFG2);
    printf("\nCFG3 = 0x%X",(UINT16)u8CFG3);
    printf("\nCFG4 = 0x%X",(UINT16)u8CFG4);
}
//-----------------------------------------------------------------------------------------------------------

void main (void) 
{
    /* Note
       MCU power on system clock is HIRC (11.0592MHz), so Fsys = 11.0592MHz
    */
    Set_All_GPIO_Quasi_Mode();
    
    #if DEBUG_PORT == 0
        InitialUART0_Timer1_Type1(9600);            /* 9600 Baud Rate*/
    #elif DEBUG_PORT == 1
        InitialUART1_Timer3(9600);                  /* 9600 Baud Rate*/
    #endif
    Show_FW_Version_Number_To_PC();
    
    printf ("\n*===================================================================");
    printf ("\n*  Name: N76E616 IAP APROM Program APROM Demo Code.");
    printf ("\n*===================================================================\n");
   
    /* Change system closk source */
    #if SYS_CLK_EN == 1
        #if   SYS_SEL == 0
            System_Clock_Select(E_HXTEN);   //Fosc = 2~16MHz XTAL
        #elif SYS_SEL == 1
            System_Clock_Select(E_LXTEN);   //Fosc = 32.768KHz XTAL
        #elif SYS_SEL == 2
            System_Clock_Select(E_HIRCEN);  //Fosc = 11.0592MHz Internal RC
        #elif SYS_SEL == 3
            System_Clock_Select(E_LIRCEN);  //Fosc = 10KHz Internal RC
        #elif SYS_SEL == 4
            System_Clock_Select(E_OSCEN);   //Fosc = OSC-In External OSC
        #endif
    #endif
    
    #if SYS_DIV_EN == 1
        CKDIV = SYS_DIV;                        //Fsys = Fosc / (2* CLKDIV) = Fcpu
    #endif
    
    Set_All_GPIO_Quasi_Mode();

    DISPLAY_LED = 0x0F;
    Timer0_Delay1ms(200);

    Erase_CONFIG();
    ID_CONFIG_Read();

    printf ("\nErase APROM");
    Erase_APROM();
    printf ("\nAPROM Erase Verify");
    if(Erase_APROM_Verify() == FAIL)
    {
        DISPLAY_LED = ERASE_FAIL;
        printf ("\nAPROM Erase Fail.");
        while(1);
    }
    printf ("\nAPROM Erase Verify Pass");    

    printf ("\nAPROM Program");        
    Program_APROM();
    printf ("\nAPROM Program Verify");        
    if(Program_APROM_Verify() == FAIL)
    {
        DISPLAY_LED = PROGRAM_FAIL;
        printf ("\nAPROM Program Fail.");
        while(1);
    }
    printf ("\nAPROM Program Verify pass");        
  
    Program_CONFIG(0x00,0xCF);      //Program CONFIG0 =  0xCF;
    Program_CONFIG(0x01,0x0F);      //Program CONFIG1 =  0x0F;
    Program_CONFIG(0x02,0xF8);      //Program CONFIG2 =  0xF8;
    Program_CONFIG(0x03,0x3F);      //Program CONFIG3 =  0x3F;
    Program_CONFIG(0x04,0xFF);      //Program CONFIG4 =  0x00;
  
    ID_CONFIG_Read();
    
    //Timer0_Delay1ms(200);
    
    printf ("\nAPROM program APROM Stop!!!"); 
    DISPLAY_LED = IAP_PASS;

    while(1);
}
//-----------------------------------------------------------------------------------------------------------
