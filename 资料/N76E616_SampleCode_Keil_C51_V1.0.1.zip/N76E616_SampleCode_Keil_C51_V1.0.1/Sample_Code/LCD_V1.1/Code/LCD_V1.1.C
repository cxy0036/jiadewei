/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2015 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

//***********************************************************************************************************
//  Nuvoton Technoledge Corp. 
//  Website: http://www.nuvoton.com
//  E-Mail : MicroC-8bit@nuvoton.com
//  Date   : Sep/1/2015
//***********************************************************************************************************

//***********************************************************************************************************
//  File Function: N76E616 LCD demo code
//***********************************************************************************************************

#include <stdio.h>
#include <N76E616.h>
#include "Version.h"
#include "Typedef.h"
#include "Define.h"
#include "SFR_Macro.h"
#include "Common.h"
#include "Delay.h"

/*
//-------- <<< Use Configuration Wizard in Context Menu >>> ------------------
//
//<e0> System Clock Source Configuration
// <o1> System Clock Source Selection
//      <0=> 2~16   MHz  XTAL (HXT)
//      <1=> 32.768 kHz  XTAL (LXT)
//      <2=> 11.059 MHz  Internal (HIRC)
//</e>
//
//<e2> Clock Divider Configuration
//     <o3.0..7>  System Clock Source Devider  <1-255:1>
//                     <i> Fsys = (System Clock Source) / (2 * Devider)
//</e>
//
// <o4> Port0 Mode Selection (P0[7:0])
//      <0=> Quasi-Bidirectional
//      <1=> Push-Pull
//      <2=> Input-Only (high-impedance)
//      <3=> Open-Drain
//
// <o5> Port1 Mode Selection (P1[7:0])
//      <0=> Quasi-Bidirectional
//      <1=> Push-Pull
//      <2=> Input-Only (high-impedance)
//      <3=> Open-Drain
//
// <o6> Port2 Mode Selection (P2[7:0])
//      <0=> Quasi-Bidirectional
//      <1=> Push-Pull
//      <2=> Input-Only (high-impedance)
//      <3=> Open-Drain
//
// <o7> Port3 Mode Selection (P3[5:0])
//      <0=> Quasi-Bidirectional
//      <1=> Push-Pull
//      <2=> Input-Only (high-impedance)
//      <3=> Open-Drain
//
// <o8> Port4 Mode Selection (P4[6:0])
//      <0=> Quasi-Bidirectional
//      <1=> Push-Pull
//      <2=> Input-Only (high-impedance)
//      <3=> Open-Drain
//
// <o9> Port5 Mode Selection (P5[7:0])
//      <0=> Quasi-Bidirectional
//      <1=> Push-Pull
//      <2=> Input-Only (high-impedance)
//      <3=> Open-Drain
//-------- <<< end of configuration section >>> ------------------------------
*/


#include <absacc.h>  

#define SYS_CLK_EN      1
#define SYS_SEL         2
#define SYS_DIV_EN      0                   //0: Fsys=Fosc, 1: Fsys = Fosc/(2*CKDIV)
#define SYS_DIV         1

#define PORT0_MODE      2
#define PORT1_MODE      2
#define PORT2_MODE      2
#define PORT3_MODE      2
#define PORT4_MODE      2
#define PORT5_MODE      2

#define COM0    0x01
#define COM1    0x02
#define COM2    0x04
#define COM3    0x08

bit BIT_TMP;

void Show_Pattern_In_LCD(void)
{
    //--------------------------------------
    
    //show "nuvoTon"
    LCDSEG3 |= SET_BIT3;                    //MCU's SEG27 enable
    LCDPTR  = 27;                           //MCU's SEG27 -- LCD's SEG37
    LCDDAT  = COM0;                         //LCD's COM0
    
    //--------------------------------------
    
    //show "N" -- 1'st 13seg Display
    LCDSEG0 |= SET_BIT0;                    //MCU's SEG0 enable
    LCDPTR  = 0;                            //MCU's SEG0 -- LCD's SEG1
    LCDDAT  = (COM1 + COM2);                //LCD's COM1/2
    
    LCDSEG0 |= SET_BIT1;                    //MCU's SEG1 enable
    LCDPTR  = 1;                            //MCU's SEG1 -- LCD's SEG2
    LCDDAT  = COM0;                         //LCD's COM0
    
    LCDSEG3 |= SET_BIT4;                    //MCU's SEG28 enable
    LCDPTR  = 28;                           //MCU's SEG1 -- LCD's SEG43
    LCDDAT  = (COM1 + COM2);                //LCD's COM1/2
    
    LCDSEG3 |= SET_BIT7;                    //MCU's SEG31 enable
    LCDPTR  = 31;                           //MCU's SEG1 -- LCD's SEG44
    LCDDAT  = COM3;                         //LCD's COM3
    
    //--------------------------------------
    
    //show "7" -- 2'nd 13seg Display
    LCDSEG0 |= SET_BIT4;                    //MCU's SEG4 enable
    LCDPTR  = 4;                            //MCU's SEG4 -- LCD's SEG5
    LCDDAT  = (COM1 + COM2 + COM3);         //LCD's COM1/2/3
    
    LCDSEG0 |= SET_BIT2;                    //MCU's SEG2 enable
    LCDPTR  = 2;                            //MCU's SEG2 -- LCD's SEG3
    LCDDAT  = COM2;                         //LCD's COM2

    //--------------------------------------
    
    //show "6" -- 3'th 13seg Display
    LCDSEG0 |= SET_BIT6;                    //MCU's SEG6 enable
    LCDPTR  = 6;                            //MCU's SEG6 -- LCD's SEG7
    LCDDAT  = (COM1 + COM2);                //LCD's COM1/2    

    LCDSEG0 |= SET_BIT7;                    //MCU's SEG7 enable
    LCDPTR  = 7;                            //MCU's SEG7 -- LCD's SEG8
    LCDDAT  = COM2;                         //LCD's COM2  
    
    LCDSEG1 |= SET_BIT0;                    //MCU's SEG8 enable
    LCDPTR  = 8;                            //MCU's SEG8 -- LCD's SEG9
    LCDDAT  = (COM0 + COM1 + COM3);         //LCD's COM0/1/3
    
    LCDSEG1 |= SET_BIT1;                    //MCU's SEG9 enable
    LCDPTR  = 9;                            //MCU's SEG9 -- LCD's SEG10
    LCDDAT  = COM1;                         //LCD's COM1
    
    //--------------------------------------
    
    //show "E" -- 4'th 13seg Display
    LCDSEG1 |= SET_BIT2;                    //MCU's SEG10 enable
    LCDPTR  = 10;                           //MCU's SEG10 -- LCD's SEG11
    LCDDAT  = (COM1 + COM2);                //LCD's COM1/2    

    LCDSEG1 |= SET_BIT3;                    //MCU's SEG11 enable
    LCDPTR  = 11;                           //MCU's SEG11 -- LCD's SEG12
    LCDDAT  = COM2;                         //LCD's COM2  
    
    LCDSEG1 |= SET_BIT4;                    //MCU's SEG12 enable
    LCDPTR  = 12;                           //MCU's SEG12 -- LCD's SEG13
    LCDDAT  = (COM0 + COM3);                //LCD's COM0/3
    
    LCDSEG1 |= SET_BIT5;                    //MCU's SEG13 enable
    LCDPTR  = 13;                           //MCU's SEG13 -- LCD's SEG14
    LCDDAT  = COM1;                         //LCD's COM1    

    //--------------------------------------
    
    //show "6" -- 9'th 7seg Display
    LCDSEG1 |= SET_BIT6;                    //MCU's SEG14 enable
    LCDPTR  = 14;                           //MCU's SEG14 -- LCD's SEG15
    LCDDAT  = (COM1 + COM2);                //LCD's COM1/2

    LCDSEG1 |= SET_BIT7;                    //MCU's SEG15 enable
    LCDPTR  = 15;                           //MCU's SEG15 -- LCD's SEG16
    LCDDAT  = COM2;                         //LCD's COM2      

    LCDSEG2 |= SET_BIT0;                    //MCU's SEG16 enable
    LCDPTR  = 16;                           //MCU's SEG16 -- LCD's SEG17
    LCDDAT  = (COM0 + COM1 + COM3);         //LCD's COM0/1/3      

    LCDSEG2 |= SET_BIT1;                    //MCU's SEG17 enable
    LCDPTR  = 17;                           //MCU's SEG17 -- LCD's SEG18
    LCDDAT  = COM1;                         //LCD's COM1      

    //--------------------------------------
    
    //show "1" -- 10'th 7seg Display
    LCDSEG2 |= SET_BIT4;                    //MCU's SEG20 enable
    LCDPTR  = 20;                           //MCU's SEG20 -- LCD's SEG21
    LCDDAT  = (COM1 + COM2);                //LCD's COM1/2

     //--------------------------------------
    
    //show "6" -- 9'th 7seg Display
    LCDSEG2 |= SET_BIT6;                    //MCU's SEG22 enable
    LCDPTR  = 22;                           //MCU's SEG22 -- LCD's SEG23
    LCDDAT  = (COM1 + COM2);                //LCD's COM1/2

    LCDSEG2 |= SET_BIT7;                    //MCU's SEG23 enable
    LCDPTR  = 23;                           //MCU's SEG23 -- LCD's SEG24
    LCDDAT  = COM2;                         //LCD's COM2      

    LCDSEG3 |= SET_BIT0;                    //MCU's SEG23 enable
    LCDPTR  = 24;                           //MCU's SEG23 -- LCD's SEG24
    LCDDAT  = (COM0 + COM1 + COM3);                //LCD's COM0/1/3

    LCDSEG3 |= SET_BIT1;                    //MCU's SEG25 enable
    LCDPTR  = 25;                           //MCU's SEG25 -- LCD's SEG26
    LCDDAT  = COM1;                         //LCD's COM1      
    
    //--------------------------------------
    
    //show "Welcome"
    LCDSEG2 |= SET_BIT6;                    //MCU's SEG22 enable
    LCDPTR  = 22;                           //MCU's SEG22 -- LCD's SEG23
    LCDDAT  |= COM3;                         //LCD's COM03
}
//-----------------------------------------------------------------------------------
void LCD_Initial(void)
{
    Set_All_GPIO_Input_Mode();

    //step1: enable clock source
    clr_EXTEN1;
    set_EXTEN0;
    
    //step2: check ready
    while((CKSWT&SET_BIT6)==0);

    
    LCDCON = 0x40;      //;VLCD = 0.9VDD (VDD = 3.3V, VLCD = 3.0V)
                        //;1/4 duty, 1/3 bias, 150kO resistor ladder
    
    LCDCLK = 0x13;      //;Select LXT as LCD clock source
    LCDCON |= SET_BIT7;  //LCDEN = 1
}
//------------------------------------------------
void LCD_Blank(void)
{
    LCDSEG0 = 0x00;
    LCDSEG1 = 0x00;
    LCDSEG2 = 0x00;
    LCDSEG3 = 0x00;
}    
/*------------------------------------------------
The main C function.  Program execution starts
here after stack initialization.
------------------------------------------------*/
void main (void) 
{
    /* Note
       MCU power on system clock is HIRC (11.0592MHz), so Fsys = 11.0592MHz
    */

#if 0    
    Set_All_GPIO_Quasi_Mode();   

    #if DEBUG_PORT == 0
        InitialUART0_Timer1_Type1(9600);            /* 9600 Baud Rate*/
    #elif DEBUG_PORT == 1
        InitialUART1_Timer3(9600);                  /* 9600 Baud Rate*/
    #endif
    Show_FW_Version_Number_To_PC();
    
    printf ("\n*===================================================================");
    printf ("\n*  Name: N76E616 LCD Demo Code.");
    printf ("\n*===================================================================\n");
#endif
    
    LCD_Initial();

    /* Change system closk source */
    #if SYS_CLK_EN == 1
        #if   SYS_SEL == 0
            System_Clock_Select(E_HXTEN);   //Fosc = 2~16MHz XTAL
        #elif SYS_SEL == 1
            System_Clock_Select(E_LXTEN);   //Fosc = 32.768KHz XTAL
        #elif SYS_SEL == 2
            System_Clock_Select(E_HIRCEN);  //Fosc = 11.0592MHz Internal RC
        #endif
    #endif

//    set_CLOEN;      //Clock out on P0.7
  
    #if SYS_DIV_EN == 1
        CKDIV = SYS_DIV;                    //Fsys = Fosc / (2* CLKDIV) = Fcpu
    #endif

  #if 0
    Set_All_GPIO_Quasi_Mode();
  #else
    #if   PORT0_MODE == 0                   //Quasi-Bidirectional
        P0M1 = 0x00;
        P0M2 = 0x00;
    #elif PORT0_MODE == 1                   //Push-Pull
        P0M1 = 0x00;
        P0M2 = 0xFF;
    #elif PORT0_MODE == 2                   //Input-Only
        P0M1 = 0xFF;
        P0M2 = 0x00;
    #elif PORT0_MODE == 3                   //Open-Drain
        P0M1 = 0xFF;
        P0M2 = 0xFF;
    #endif

    #if   PORT1_MODE == 0                   //Quasi-Bidirectional
        P1M1 = 0x00;
        P1M2 = 0x00;
    #elif PORT1_MODE == 1                   //Push-Pull
        P1M1 = 0x00;
        P1M2 = 0xFF;
    #elif PORT1_MODE == 2                   //Input-Only
        P1M1 = 0xFF;
        P1M2 = 0x00;
    #elif PORT1_MODE == 3                   //Open-Drain
        P1M1 = 0xFF;
        P1M2 = 0xFF;
    #endif

    #if   PORT2_MODE == 0                   //Quasi-Bidirectional
        P2M1 = 0x00;
        P2M2 = 0x00;
    #elif PORT2_MODE == 1                   //Push-Pull
        P2M1 = 0x00;
        P2M2 = 0xFF;
    #elif PORT2_MODE == 2                   //Input-Only
        P2M1 = 0xFF;
        P2M2 = 0x00;
    #elif PORT2_MODE == 3                   //Open-Drain
        P2M1 = 0xFF;
        P2M2 = 0xFF;
    #endif

    #if   PORT3_MODE == 0                   //Quasi-Bidirectional
        P3M1 = 0x00;
        P3M2 = 0x00;
    #elif PORT3_MODE == 1                   //Push-Pull
        P3M1 = 0x00;
        P3M2 = 0x7F;
    #elif PORT3_MODE == 2                   //Input-Only
        P3M1 = 0x7F;
        P3M2 = 0x00;
    #elif PORT3_MODE == 3                   //Open-Drain
        P3M1 = 0x7F;
        P3M2 = 0x7F;
    #endif

    #if   PORT4_MODE == 0                   //Quasi-Bidirectional
        P4M1 = 0x00;
        P4M2 = 0x00;
    #elif PORT4_MODE == 1                   //Push-Pull
        P4M1 = 0x00;
        P4M2 = 0x7F;
    #elif PORT4_MODE == 2                   //Input-Only
        P4M1 = 0x7F;
        P4M2 = 0x00;
    #elif PORT4_MODE == 3                   //Open-Drain
        P4M1 = 0x7F;
        P4M2 = 0x7F;
    #endif

    #if   PORT5_MODE == 0                   //Quasi-Bidirectional
        P5M1 = 0x00;
        P5M2 = 0x00;
    #elif PORT5_MODE == 1                   //Push-Pull
        P5M1 = 0x00;
        P5M2 = 0xFF;
    #elif PORT5_MODE == 2                   //Input-Only
        P5M1 = 0xFF;
        P5M2 = 0x00;
    #elif PORT5_MODE == 3                   //Open-Drain
        P5M1 = 0xFF;
        P5M2 = 0xFF;
    #endif
  #endif

    while(1)
    {
        Show_Pattern_In_LCD();
        Timer0_Delay1ms(500);
        LCD_Blank();
        Timer0_Delay1ms(500);
    }
}
