/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2015 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

//***********************************************************************************************************
//  Nuvoton Technoledge Corp. 
//  Website: http://www.nuvoton.com
//  E-Mail : MicroC-8bit@nuvoton.com
//  Date   : Sep/1/2015
//***********************************************************************************************************

//***********************************************************************************************************
//  File Function: N76E616 GPIO demo code
//***********************************************************************************************************

#include <stdio.h>
#include <N76E616.h>
#include "Version.h"
#include "Typedef.h"
#include "Define.h"
#include "SFR_Macro.h"
#include "Common.h"
#include "Delay.h"

/*
//-------- <<< Use Configuration Wizard in Context Menu >>> ------------------
//
//<e0> System Clock Source Configuration
// <o1> System Clock Source Selection
//      <0=> 2~16   MHz  XTAL (HXT)
//      <1=> 32.768 kHz  XTAL (LXT)
//      <2=> 11.059 MHz  Internal (HIRC)
//</e>
//
//<e2> Clock Divider Configuration
//     <o3.0..7>  System Clock Source Devider  <1-255:1>
//                     <i> Fsys = (System Clock Source) / (2 * Devider)
//</e>
//
// <o4> Port0 Mode Selection (P0[7:0])
//      <0=> Quasi-Bidirectional
//      <1=> Push-Pull
//      <2=> Input-Only (high-impedance)
//      <3=> Open-Drain
//
// <o5> Port1 Mode Selection (P1[7:0])
//      <0=> Quasi-Bidirectional
//      <1=> Push-Pull
//      <2=> Input-Only (high-impedance)
//      <3=> Open-Drain
//
// <o6> Port2 Mode Selection (P2[7:0])
//      <0=> Quasi-Bidirectional
//      <1=> Push-Pull
//      <2=> Input-Only (high-impedance)
//      <3=> Open-Drain
//
// <o7> Port3 Mode Selection (P3[5:0])
//      <0=> Quasi-Bidirectional
//      <1=> Push-Pull
//      <2=> Input-Only (high-impedance)
//      <3=> Open-Drain
//
// <o8> Port4 Mode Selection (P4[6:0])
//      <0=> Quasi-Bidirectional
//      <1=> Push-Pull
//      <2=> Input-Only (high-impedance)
//      <3=> Open-Drain
//
// <o9> Port5 Mode Selection (P5[7:0])
//      <0=> Quasi-Bidirectional
//      <1=> Push-Pull
//      <2=> Input-Only (high-impedance)
//      <3=> Open-Drain
//-------- <<< end of configuration section >>> ------------------------------
*/


#include <absacc.h>  

#define SYS_CLK_EN      0
#define SYS_SEL         2
#define SYS_DIV_EN      0                   //0: Fsys=Fosc, 1: Fsys = Fosc/(2*CKDIV)
#define SYS_DIV         1

#define PORT0_MODE      0
#define PORT1_MODE      0
#define PORT2_MODE      0
#define PORT3_MODE      0
#define PORT4_MODE      0
#define PORT5_MODE      0

bit BIT_TMP;

/*------------------------------------------------
The main C function.  Program execution starts
here after stack initialization.
------------------------------------------------*/
void main (void) 
{
    /* Note
       MCU power on system clock is HIRC (11.0592MHz), so Fsys = 11.0592MHz
    */
    
    Set_All_GPIO_Quasi_Mode();                   //in Common.c

    #if DEBUG_PORT == 0
        InitialUART0_Timer1_Type1(9600);            /* 9600 Baud Rate*/
    #elif DEBUG_PORT == 1
        InitialUART1_Timer3(9600);                  /* 9600 Baud Rate*/
    #endif  
    Show_FW_Version_Number_To_PC();
    
    printf ("\n*===================================================================");
    printf ("\n*  Name: N76E616 GPIO Toggling Demo Code.");
    printf ("\n*===================================================================\n");

    /* Change system closk source */
    #if SYS_CLK_EN == 1
        #if   SYS_SEL == 0
            System_Clock_Select(E_HXTEN);   //Fosc = 2~16MHz XTAL
        #elif SYS_SEL == 1
            System_Clock_Select(E_LXTEN);   //Fosc = 32.768KHz XTAL
        #elif SYS_SEL == 2
            System_Clock_Select(E_HIRCEN);  //Fosc = 11.0592MHz Internal RC
        #endif
    #endif
    
    #if SYS_DIV_EN == 1
        CKDIV = SYS_DIV;                    //Fsys = Fosc / (2* CLKDIV) = Fcpu
    #endif
  
  #if 1
    Set_All_GPIO_Quasi_Mode();
  #else
    #if   PORT0_MODE == 0                   //Quasi-Bidirectional
        P0M1 = 0x00;
        P0M2 = 0x00;
    #elif PORT0_MODE == 1                   //Push-Pull
        P0M1 = 0x00;
        P0M2 = 0xFF;
    #elif PORT0_MODE == 2                   //Input-Only
        P0M1 = 0xFF;
        P0M2 = 0x00;
    #elif PORT0_MODE == 3                   //Open-Drain
        P0M1 = 0xFF;
        P0M2 = 0xFF;
    #endif

    #if   PORT1_MODE == 0                   //Quasi-Bidirectional
        P1M1 = 0x00;
        P1M2 = 0x00;
    #elif PORT1_MODE == 1                   //Push-Pull
        P1M1 = 0x00;
        P1M2 = 0xFF;
    #elif PORT1_MODE == 2                   //Input-Only
        P1M1 = 0xFF;
        P1M2 = 0x00;
    #elif PORT1_MODE == 3                   //Open-Drain
        P1M1 = 0xFF;
        P1M2 = 0xFF;
    #endif

    #if   PORT2_MODE == 0                   //Quasi-Bidirectional
        P2M1 = 0x00;
        P2M2 = 0x00;
    #elif PORT2_MODE == 1                   //Push-Pull
        P2M1 = 0x00;
        P2M2 = 0xFF;
    #elif PORT2_MODE == 2                   //Input-Only
        P2M1 = 0xFF;
        P2M2 = 0x00;
    #elif PORT2_MODE == 3                   //Open-Drain
        P2M1 = 0xFF;
        P2M2 = 0xFF;
    #endif

    #if   PORT3_MODE == 0                   //Quasi-Bidirectional
        P3M1 = 0x00;
        P3M2 = 0x00;
    #elif PORT3_MODE == 1                   //Push-Pull
        P3M1 = 0x00;
        P3M2 = 0x3F;
    #elif PORT3_MODE == 2                   //Input-Only
        P3M1 = 0x3F;
        P3M2 = 0x00;
    #elif PORT3_MODE == 3                   //Open-Drain
        P3M1 = 0x3F;
        P3M2 = 0x3F;
    #endif

    #if   PORT4_MODE == 0                   //Quasi-Bidirectional
        P4M1 = 0x00;
        P4M2 = 0x00;
    #elif PORT3_MODE == 1                   //Push-Pull
        P4M1 = 0x00;
        P4M2 = 0x3F;
    #elif PORT3_MODE == 2                   //Input-Only
        P4M1 = 0x3F;
        P4M2 = 0x00;
    #elif PORT3_MODE == 3                   //Open-Drain
        P4M1 = 0x3F;
        P4M2 = 0x3F;
    #endif

    #if   PORT5_MODE == 0                   //Quasi-Bidirectional
        P5M1 = 0x00;
        P5M2 = 0x00;
    #elif PORT3_MODE == 1                   //Push-Pull
        P5M1 = 0x00;
        P5M2 = 0xFF;
    #elif PORT3_MODE == 2                   //Input-Only
        P5M1 = 0xFF;
        P5M2 = 0x00;
    #elif PORT3_MODE == 3                   //Open-Drain
        P5M1 = 0xFF;
        P5M2 = 0xFF;
    #endif
  #endif
  
  #define N 10
  
  while(1)
  {
        P02 = 0;
        Timer3_Delay1ms(N*4);
        P03 = 0;
        
        Timer0_Delay1ms(N*1);
        Timer3_Delay1ms(N*4);
        WakeUp_Timer_Delay25ms(1);          //Clock source is always 10KHz
        
        P02 = 1;
        Timer3_Delay1ms(N*4);
        P03 = 1;
        
        Timer0_Delay1ms(N*1);
        Timer3_Delay1ms(N*4);
        WakeUp_Timer_Delay25ms(1);          //Clock source is always 10KHz
    }
}
