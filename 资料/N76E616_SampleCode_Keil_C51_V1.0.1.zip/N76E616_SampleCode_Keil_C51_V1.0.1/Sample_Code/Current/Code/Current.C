/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2015 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

//***********************************************************************************************************
//  Nuvoton Technoledge Corp. 
//  Website: http://www.nuvoton.com
//  E-Mail : MicroC-8bit@nuvoton.com
//  Date   : Sep/1/2015
//***********************************************************************************************************

//***********************************************************************************************************
//  File Function: N76E616 Current demo code
//***********************************************************************************************************

#include <stdio.h>
#include "N76E616.h"
#include "Version.h"
#include "Typedef.h"
#include "Define.h"
#include "SFR_Macro.h"
#include "Common.h"
#include "Delay.h"

/*
//-------- <<< Use Configuration Wizard in Context Menu >>> ------------------
//
//<e0> System Clock Source Configuration
// <o1> System Clock Source Selection
//      <0=> 2~16MHz    XTAL
//      <1=> 32.768KHz  XTAL
//      <2=> 11.0592MHz Internal
//      <3=> 10KHz      Internal
//      <4=> OSC-In     External
//</e>
//
//<e2> Clock Divider Configuration
//     <o3.0..7>  System Clock Source Devider <1-255:1>
//                     <i> Fsys = (System Clock Source) / (2 * Devider)
//</e>
//
//<e4> Brown-out Detection Control 0
// <o5> Brown-out Detection voltage Selection
//      <0=> BOD4.3V
//      <1=> BOD3.8V
//      <2=> BOD2.7V
//      <3=> BOD2.2V
//</e>
//
//<e6> Brown-out Detection Filter Control
//</e>
//
// <o7> Brown-out Detection Low Power Mode Selection
//      <0=> BOD Normal mode
//      <1=> BOD low power mode 1
//      <2=> BOD low power mode 2
//      <3=> BOD low power mode 3
//
// <o8> System Operate Mode Selection
//      <0=> Normal mode
//      <1=> Idle mode
//      <2=> Power down mode
//-------- <<< end of configuration section >>> ------------------------------
*/

#define SYS_CLK_EN      1
#define SYS_SEL         3
#define SYS_DIV_EN      0                   //0: Fsys=Fosc, 1: Fsys = Fosc/(2*CKDIV)
#define SYS_DIV         1
#define BOD_EN          0
#define BOD_VOLT_SEL    0
#define BOD_FILTER_EN   0
#define BOD_MODE_SEL    0
#define SYS_OP_MODE_SEL 2

bit BIT_TMP;



/******************************************************************************
The main C function.  Program execution starts
here after stack initialization.
******************************************************************************/
void main (void) 
{
    /* Note
       MCU power on system clock is HIRC (11.0592MHz), so Fsys = 11.0592MHz
    */
    
    Set_All_GPIO_Quasi_Mode();

    #if DEBUG_PORT == 0
        InitialUART0_Timer1_Type1(9600);            /* 9600 Baud Rate*/
    #elif DEBUG_PORT == 1
        InitialUART1_Timer3(9600);                  /* 9600 Baud Rate*/
    #endif  
    Show_FW_Version_Number_To_PC();

    printf ("\n*===================================================================");
    printf ("\n*  Name: N76E616 Current Demo Code.");
    printf ("\n*===================================================================\n");
        
    /* Change system closk source */
    #if SYS_CLK_EN == 1
        #if   SYS_SEL == 1
            System_Clock_Select(E_HXTEN);   //Fosc = 2~16MHz XTAL
        #elif SYS_SEL == 1
            System_Clock_Select(E_LXTEN);   //Fosc = 32.768KHz XTAL        
        #elif SYS_SEL == 2
            System_Clock_Select(E_HIRCEN);  //Fosc = 11.0592MHz Internal RC
        #elif SYS_SEL == 3
            System_Clock_Select(E_LIRCEN);  //Fosc = 10KHz Internal RC
        #elif SYS_SEL == 4
            System_Clock_Select(E_OSCEN);   //Fosc = OSC-In External OSC
        #endif
    #endif
    
    /* Turn off other none system closk sources */
    #if   SYS_SEL == 1                      //Fosc = 2~16MHz XTAL
        clr_HIRCEN;
        clr_LIRCEN;
    #elif SYS_SEL == 2                      //Fosc = 11.0592MHz Internal RC
        clr_EXTEN1;
        clr_EXTEN0;
        clr_LIRCEN;
    #elif SYS_SEL == 3                      //Fosc = 10KHz Internal RC
        clr_EXTEN1;
        clr_EXTEN0;
        clr_HIRCEN;
    #elif SYS_SEL == 4                      //Fosc = OSC-In External OSC
        clr_HIRCEN;
        clr_LIRCEN;
    #endif
           
    #if SYS_DIV_EN == 1
        CKDIV = SYS_DIV;                    //Fsys = Fosc / (2* CLKDIV) = Fcpu
    #endif
    
    /* Turn on/off BOD function */
    #if   BOD_EN == 0
        clr_BODEN;
    #elif BOD_EN == 1
        set_BODEN;
    #endif
    
    /* BOD voltage selection */
    #if   BOD_VOLT_SEL == 0
        clr_BOV1;
        clr_BOV0;
    #elif BOD_VOLT_SEL == 1
        clr_BOV1;
        set_BOV0;
    #elif BOD_VOLT_SEL == 2
        set_BOV1;
        clr_BOV0;
    #elif BOD_VOLT_SEL == 3
        set_BOV1;
        set_BOV0;
    #endif
    
    /* BOD filter control */
    #if   BOD_FILTER_EN == 0
        clr_BODFLT;
    #elif   BOD_FILTER_EN == 1
        set_BODFLT;
    #endif    
    
    /* BOD low power mode selection */
    #if   BOD_MODE_SEL == 0
        clr_LPBOD1;
        clr_LPBOD0;
    #elif BOD_MODE_SEL == 1
        clr_LPBOD1;
        set_LPBOD0;
    #elif BOD_MODE_SEL == 2
        set_LPBOD1;
        clr_LPBOD0;
    #elif BOD_MODE_SEL == 3
        set_LPBOD1;
        set_LPBOD0;
    #endif
    
    /* System operate mode selection */
    #if   SYS_OP_MODE_SEL == 0
        while(1);
    #elif SYS_OP_MODE_SEL == 1
        set_IDLE;
        while(1);
    #elif SYS_OP_MODE_SEL == 2
        set_PD;
        while(1);
    #endif

while(1);

}


