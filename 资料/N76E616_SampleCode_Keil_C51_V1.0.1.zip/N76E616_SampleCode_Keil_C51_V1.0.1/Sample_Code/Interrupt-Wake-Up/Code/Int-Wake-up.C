/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2015 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

//***********************************************************************************************************
//  Nuvoton Technoledge Corp. 
//  Website: http://www.nuvoton.com
//  E-Mail : MicroC-8bit@nuvoton.com
//  Date   : Sep/1/2015
//***********************************************************************************************************

//***********************************************************************************************************
//  File Function: N76E616 Interrupt power down wake-up demo code
//***********************************************************************************************************

#include <stdio.h>
#include "N76E616.h"
#include "Version.h"
#include "Typedef.h"
#include "Define.h"
#include "SFR_Macro.h"
#include "Common.h"
#include "Delay.h"

/*
//-------- <<< Use Configuration Wizard in Context Menu >>> ------------------
//
//<e0> System Clock Source Configuration
// <o1> System Clock Source Selection
//      <0=> 2~16MHz    XTAL
//      <1=> 32.768KHz  XTAL
//      <2=> 11.0592MHz Internal
//      <3=> 10KHz      Internal
//      <4=> OSC-In     External
//</e>
//
//<e2> Clock Divider Configuration
//     <o3.0..7>  System Clock Source Devider <1-255:1>
//                     <i> Fsys = (System Clock Source) / (2 * Devider)
//</e>
//
//<h> Port Interrupt Option
// <o4.0..2> Port Pin Selection <0=> Port0 <1=> Port1  <2=> Port2  <3=> Port3  <4=> Port4 <5=> Port5
//  <h> Edge/Level
//      <q5.0> Channel 0,   trigger type selection <0=> Level <1=> Edge
//      <q5.1> Channel 1,   trigger type selection <0=> Level <1=> Edge
//      <q5.2> Channel 2,   trigger type selection <0=> Level <1=> Edge
//      <q5.3> Channel 3,   trigger type selection <0=> Level <1=> Edge
//      <q5.4> Channel 4,   trigger type selection <0=> Level <1=> Edge
//      <q5.5> Channel 5,   trigger type selection <0=> Level <1=> Edge
//      <q5.6> Channel 6,   trigger type selection <0=> Level <1=> Edge
//      <q5.7> Channel 7,   trigger type selection <0=> Level <1=> Edge
//  </h>
//  <h>  Falling/Level
//      <q6.0> Channel 0, Enabled level/falling edge detect.
//      <q6.1> Channel 1, Enabled level/falling edge detect.
//      <q6.2> Channel 2, Enabled level/falling edge detect.
//      <q6.3> Channel 3, Enabled level/falling edge detect.
//      <q6.4> Channel 4, Enabled level/falling edge detect.
//      <q6.5> Channel 5, Enabled level/falling edge detect.
//      <q6.6> Channel 6, Enabled level/falling edge detect.
//      <q6.7> Channel 7, Enabled level/falling edge detect.
//  </h>
//  <h>  Rising/Level
//      <q7.0> Channel 0, Enabled level/rising edge detect.
//      <q7.1> Channel 1, Enabled level/rising edge detect.
//      <q7.2> Channel 2, Enabled level/rising edge detect.
//      <q7.3> Channel 3, Enabled level/rising edge detect.
//      <q7.4> Channel 4, Enabled level/rising edge detect.
//      <q7.5> Channel 5, Enabled level/rising edge detect.
//      <q7.6> Channel 6, Enabled level/rising edge detect.
//      <q7.7> Channel 7, Enabled level/rising edge detect.
//  </h>
//</h>
//
//-------- <<< end of configuration section >>> ------------------------------
*/

#define SYS_CLK_EN      0
#define SYS_SEL         2
#define SYS_DIV_EN      0                   //0: Fsys=Fosc, 1: Fsys = Fosc/(2*CKDIV)
#define SYS_DIV         1
#define PICON_VAL       0x02                //Pin Interrupt Control
#define PITYP_VAL       0xFF                //Pin Interrupt Type
#define PINEN_VAL       0xFF                //Pin Interrupt Negative Polarity Enable.
#define PIPEN_VAL       0x00                //Pin Interrupt Positive Polarity Enable.

bit BIT_TMP;

/*----------------------------------------------------------------------------
  Check the register settings
 *----------------------------------------------------------------------------*/
#define CHECK_RANGE(val, min, max)          ((val < min) || (val > max))
#define CHECK_RSVD(val, mask)               (val & mask)

#if (PICON_VAL&0x07) == 0x03  //Port3, only P3[7] useless
    #if CHECK_RSVD(PINEN_VAL, ~0x7F)
        #error "Port3[7] Interrup Pin Select Error"
    #elif CHECK_RSVD(PIPEN_VAL, ~0x07)
        #error "Port3[7] Interrup Pin Select Error"
    #endif
#endif

#if (PICON_VAL&0x07) == 0x04  //Port4, only P4[7] useless
    #if CHECK_RSVD(PINEN_VAL, ~0x7F)
        #error "Port4[7] Interrup Pin Select Error"
    #elif CHECK_RSVD(PIPEN_VAL, ~0x7F)
        #error "Port4[7] Interrup Pin Select Error"
    #endif
#endif

/*****************************************************************************/
void INT0_ISR (void)            interrupt 0
{
    clr_IE0;                                    //clear interrupt flag
    clr_P02;
    Delay10us(1);
    set_P02;
}
/*****************************************************************************/
void INT1_ISR (void)            interrupt 2
{
    clr_IE1;                                    //clear interrupt flag
    clr_P02;
    Delay10us(2);
    set_P02;
}
void PinInterrupt_ISR (void) interrupt 7
{
    PIF = 0x00;                             //clear interrupt flag
    
    #if (PICON_VAL&0x07) == 0x00            //Port0 are interrupt pin
    clr_P02;
    Delay10us(3);
    set_P02;
    #endif
    
    #if (PICON_VAL&0x07) == 0x01            //Port1 are interrupt pin
    clr_P02;
    Delay10us(4);
    set_P02;
    #endif
    
    #if (PICON_VAL&0x07) == 0x02            //Port2 are interrupt pin
    clr_P02;
    Delay10us(5);
    set_P02;
    #endif
    
    #if (PICON_VAL&0x07) == 0x03            //Port3 are interrupt pin
    clr_P02;
    Delay10us(6);
    set_P02;
    #endif

    #if (PICON_VAL&0x07) == 0x04            //Port4 are interrupt pin
    clr_P02;
    Delay10us(7);
    set_P02;
    #endif

    #if (PICON_VAL&0x07) == 0x05            //Port5 are interrupt pin
    clr_P02;
    Delay10us(8);
    set_P02;
    #endif

}
/*****************************************************************************/
void Brown_Out_ISR (void)       interrupt 8
{
    clr_BOF;                                    //clear interrupt flag
    clr_P03;
    Delay10us(1);
    set_P03;
}
/*****************************************************************************/
void WakeUp_Timer_ISR (void)   interrupt 17     //ISR for self wake-up timer
{
    clr_WKTF;                                   //clear interrupt flag
    clr_WKTR;                                   //Wake-up timer halt 
    clr_P03;
    Delay10us(2);
    set_P03;
}

/******************************************************************************
The main C function.  Program execution starts
here after stack initialization.
******************************************************************************/
void main (void) 
{
    /* Note
       MCU power on system clock is HIRC (11.0592MHz), so Fsys = 11.0592MHz
    */
    
    Set_All_GPIO_Quasi_Mode();                   //in Common.c

    #if DEBUG_PORT == 0
        InitialUART0_Timer1_Type1(9600);            /* 9600 Baud Rate*/
    #elif DEBUG_PORT == 1
        InitialUART1_Timer3(9600);                  /* 9600 Baud Rate*/
    #endif  

    Show_FW_Version_Number_To_PC();

    printf ("\n*===================================================================");
    printf ("\n*  Name: N76E616 Powr Down Wake-up from Interrupt function.");
    printf ("\n*===================================================================\n");
        
    /* Change system closk source */
    #if SYS_CLK_EN == 1
        #if   SYS_SEL == 0
            System_Clock_Select(E_HXTEN);   //Fosc = 2~16MHz XTAL
        #elif SYS_SEL == 1
            System_Clock_Select(E_LXTEN);   //Fosc = 32.768KHz XTAL
        #elif SYS_SEL == 2
            System_Clock_Select(E_HIRCEN);  //Fosc = 11.0592MHz Internal RC
        #elif SYS_SEL == 3
            System_Clock_Select(E_LIRCEN);  //Fosc = 10KHz Internal RC
        #elif SYS_SEL == 4
            System_Clock_Select(E_OSCEN);   //Fosc = OSC-In External OSC
        #endif
    #endif
    
    #if SYS_DIV_EN == 1
        CKDIV = SYS_DIV;                        //Fsys = Fosc / (2* CLKDIV) = Fcpu
    #endif

    P0 = 0xFF;
    P1 = 0xFF;
    P2 = 0xFF;
    P3 = 0x7F;
    P4 = 0x7F;
    P5 = 0xFF;

    /* For Pin, INT0 & INT1 Interrupt */
    PICON = PICON_VAL;
    PITYP = PITYP_VAL;
    PINEN = PINEN_VAL;
    PIPEN = PIPEN_VAL;
    
    set_EX0;                                    //INT0
    set_EX1;                                    //INT1
    set_EPI;                                    //Pin

    /* For BOD Interrupt */
    set_BODEN;
    set_BOV1;
    clr_BOV0;
    clr_BOF;
    clr_BORST;
    
    set_EBOD;                                   //Brown Out
    
    /* For WKT Interrupt */
    clr_WKTCK;
    clr_WKPS2;
    clr_WKPS1;
    clr_WKPS0;

    set_EWKT;

    RWK=0x00;
    
    clr_WKTF;
    set_WKTR;                                   //Wake-up timer run 

    EA = 1;

    while(1)
    {
        set_PD;                                 //Enter Power Down
    }
}


