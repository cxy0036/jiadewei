/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2015 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

//***********************************************************************************************************
//  Nuvoton Technoledge Corp. 
//  Website: http://www.nuvoton.com
//  E-Mail : MicroC-8bit@nuvoton.com
//  Date   : Sep/1/2015
//***********************************************************************************************************

//***********************************************************************************************************
//  File Function: N76E616 Timer2 PWM mode demo code
//***********************************************************************************************************

#include <stdio.h>
#include <N76E616.h>
#include "Version.h"
#include "Typedef.h"
#include "Define.h"
#include "SFR_Macro.h"
#include "Common.h"
#include "Delay.h"

/*
//-------- <<< Use Configuration Wizard in Context Menu >>> ------------------
//
//<e0> System Clock Source Configuration
// <o1> System Clock Source Selection
//      <0=> 2~16   MHz  XTAL (HXT)
//      <1=> 32.768 kHz  XTAL (LXT)
//      <2=> 11.059 MHz  Internal (HIRC)
//</e>
//
//<e2> Clock Divider Configuration
//     <o3.0..7>  System Clock Source Devider  <1-255:1>
//                     <i> Fsys = (System Clock Source) / (2 * Devider)
//</e>
//
// <o4> Port0 Mode Selection (P0[7:0])
//      <0=> Quasi-Bidirectional
//      <1=> Push-Pull
//      <2=> Input-Only (high-impedance)
//      <3=> Open-Drain
//
// <o5> Port1 Mode Selection (P1[7:0])
//      <0=> Quasi-Bidirectional
//      <1=> Push-Pull
//      <2=> Input-Only (high-impedance)
//      <3=> Open-Drain
//
// <o6> Port2 Mode Selection (P2[7:0])
//      <0=> Quasi-Bidirectional
//      <1=> Push-Pull
//      <2=> Input-Only (high-impedance)
//      <3=> Open-Drain
//
// <o7> Port3 Mode Selection (P3[5:0])
//      <0=> Quasi-Bidirectional
//      <1=> Push-Pull
//      <2=> Input-Only (high-impedance)
//      <3=> Open-Drain
//
// <o8> Port4 Mode Selection (P4[6:0])
//      <0=> Quasi-Bidirectional
//      <1=> Push-Pull
//      <2=> Input-Only (high-impedance)
//      <3=> Open-Drain
//
// <o9> Port5 Mode Selection (P5[7:0])
//      <0=> Quasi-Bidirectional
//      <1=> Push-Pull
//      <2=> Input-Only (high-impedance)
//      <3=> Open-Drain
//
// <o10> Timer 2A pre-scalar (T2APS[2:0])
//      <0=> PS_one
//      <1=> PS_2
//      <2=> PS_8
//      <3=> PS_6
//      <4=> PS_64
//      <5=> PS_128
//      <6=> PS_512
//      <7=> PS_1024
//
// <o11> Timer 2A Reload Low Byte Value
//      <0=> 1
//      <1=> 255
// <o12> Timer 2A Reload High Byte Value
//      <0=> 1
//      <1=> 255
//-------- <<< end of configuration section >>> ------------------------------
*/


#include <absacc.h>  

#define SYS_CLK_EN      1
#define SYS_SEL         2
#define SYS_DIV_EN      0                   //0: Fsys=Fosc, 1: Fsys = Fosc/(2*CKDIV)
#define SYS_DIV         1

#define PORT0_MODE      0
#define PORT1_MODE      0
#define PORT2_MODE      0
#define PORT3_MODE      0
#define PORT4_MODE      0
#define PORT5_MODE      0

#define TMR2A_PS        7

#define TMR2A_LBYTE     1
#define TMR2A_HBYTE     1

bit BIT_TMP;

/************************************************************************************************************
*    Timer2 interrupt subroutine
************************************************************************************************************/
void Timer2_ISR (void) interrupt 5
{
    clr_TF2A;                                    //Clear Timer2 Interrupt Flag
    P02 = ~P02;
    P03 = ~P03;
}

/*------------------------------------------------
The main C function.  Program execution starts
here after stack initialization.
------------------------------------------------*/
void main (void) 
{
    /* Note
       MCU power on system clock is HIRC (11.0592MHz), so Fsys = 11.0592MHz
    */
    
    Set_All_GPIO_Quasi_Mode();                   //in Common.c

    #if DEBUG_PORT == 0
        InitialUART0_Timer1_Type1(9600);            /* 9600 Baud Rate*/
    #elif DEBUG_PORT == 1
        InitialUART1_Timer3(9600);                  /* 9600 Baud Rate*/
    #endif
    Show_FW_Version_Number_To_PC();
    
    printf ("\n*===================================================================");
    printf ("\n*  Name: N76E616 Timer2 Auto Reload Demo Code.");
    printf ("\n*===================================================================\n");

    /* Change system closk source */
    #if SYS_CLK_EN == 1
        #if   SYS_SEL == 0
            System_Clock_Select(E_HXTEN);       //Fosc = 2~16MHz XTAL
        #elif SYS_SEL == 1
            System_Clock_Select(E_LXTEN);       //Fosc = 32.768KHz XTAL
        #elif SYS_SEL == 2
            System_Clock_Select(E_HIRCEN);      //Fosc = 11.0592MHz Internal RC
        #endif
    #endif
    
    #if SYS_DIV_EN == 1
        CKDIV = SYS_DIV;                        //Fsys = Fosc / (2* CLKDIV) = Fcpu
    #endif
  
  #if 1
    Set_All_GPIO_Quasi_Mode();
  #else
    #if   PORT0_MODE == 0                       //Quasi-Bidirectional
        P0M1 = 0x00;
        P0M2 = 0x00;
    #elif PORT0_MODE == 1                       //Push-Pull
        P0M1 = 0x00;
        P0M2 = 0xFF;
    #elif PORT0_MODE == 2                       //Input-Only
        P0M1 = 0xFF;
        P0M2 = 0x00;
    #elif PORT0_MODE == 3                       //Open-Drain
        P0M1 = 0xFF;
        P0M2 = 0xFF;
    #endif

    #if   PORT1_MODE == 0                       //Quasi-Bidirectional
        P1M1 = 0x00;
        P1M2 = 0x00;
    #elif PORT1_MODE == 1                       //Push-Pull
        P1M1 = 0x00;
        P1M2 = 0xFF;
    #elif PORT1_MODE == 2                       //Input-Only
        P1M1 = 0xFF;
        P1M2 = 0x00;
    #elif PORT1_MODE == 3                       //Open-Drain
        P1M1 = 0xFF;
        P1M2 = 0xFF;
    #endif

    #if   PORT2_MODE == 0                       //Quasi-Bidirectional
        P2M1 = 0x00;
        P2M2 = 0x00;
    #elif PORT2_MODE == 1                       //Push-Pull
        P2M1 = 0x00;
        P2M2 = 0xFF;
    #elif PORT2_MODE == 2                       //Input-Only
        P2M1 = 0xFF;
        P2M2 = 0x00;
    #elif PORT2_MODE == 3                       //Open-Drain
        P2M1 = 0xFF;
        P2M2 = 0xFF;
    #endif

    #if   PORT3_MODE == 0                       //Quasi-Bidirectional
        P3M1 = 0x00;
        P3M2 = 0x00;
    #elif PORT3_MODE == 1                       //Push-Pull
        P3M1 = 0x00;
        P3M2 = 0x3F;
    #elif PORT3_MODE == 2                       //Input-Only
        P3M1 = 0x3F;
        P3M2 = 0x00;
    #elif PORT3_MODE == 3                       //Open-Drain
        P3M1 = 0x3F;
        P3M2 = 0x3F;
    #endif

    #if   PORT4_MODE == 0                       //Quasi-Bidirectional
        P4M1 = 0x00;
        P4M2 = 0x00;
    #elif PORT3_MODE == 1                       //Push-Pull
        P4M1 = 0x00;
        P4M2 = 0x3F;
    #elif PORT3_MODE == 2                       //Input-Only
        P4M1 = 0x3F;
        P4M2 = 0x00;
    #elif PORT3_MODE == 3                       //Open-Drain
        P4M1 = 0x3F;
        P4M2 = 0x3F;
    #endif

    #if   PORT5_MODE == 0                       //Quasi-Bidirectional
        P5M1 = 0x00;
        P5M2 = 0x00;
    #elif PORT3_MODE == 1                       //Push-Pull
        P5M1 = 0x00;
        P5M2 = 0xFF;
    #elif PORT3_MODE == 2                       //Input-Only
        P5M1 = 0xFF;
        P5M2 = 0x00;
    #elif PORT3_MODE == 3                       //Open-Drain
        P5M1 = 0xFF;
        P5M2 = 0xFF;
    #endif
  #endif

  
    /*  PWM period = (R2AH + R2AL) * Pre-scale / Fsys, Fsys = 11.0592MHz (HIRC)
        If R2AH = R2AL, PWM output 50% duty cycle
        Min frequency is about 20Hz, while Pre-scale = 1/1024 and R2AH = R2AL = 255
        Max frequency is around 5.5MHz, while Pre-scale = 1/1 and R2AH = R2AL = 1   */

    /* Determine Timer 2A pre-scalar */
    #if   TMR2A_PS == 0
        clr_T2APS2;
        clr_T2APS1;
        clr_T2APS0;
    #elif TMR2A_PS == 1
        clr_T2APS2;
        clr_T2APS1;
        set_T2APS0;   
    #elif TMR2A_PS == 2
        clr_T2APS2;
        set_T2APS1;
        clr_T2APS0;
    #elif TMR2A_PS == 3
        clr_T2APS2;
        set_T2APS1;
        set_T2APS0;
    #elif TMR2A_PS == 4
        set_T2APS2;
        clr_T2APS1;
        clr_T2APS0;
    #elif TMR2A_PS == 5
        set_T2APS2;
        clr_T2APS1;
        set_T2APS0;
    #elif TMR2A_PS == 6
        set_T2APS2;
        set_T2APS1;
        clr_T2APS0;
    #elif TMR2A_PS == 7
        set_T2APS2;
        set_T2APS1;
        set_T2APS0;
    #endif

    /* Determine Timer 2A Reload Low Byte */
    #if   TMR2A_LBYTE == 0
        R2AL = 1;
    #elif TMR2A_LBYTE == 1
        R2AL = 255;
    #endif  
    
    /* Determine Timer 2A Reload High Byte */
    #if   TMR2A_HBYTE == 0
        R2AH = 1;
    #elif TMR2A_HBYTE == 1
        R2AH = 255;
    #endif    
    
    /* Set T2A as PWM mode */
    set_T2AM;

    /* Enable Timer2A interrupt */
    set_ET2A;                                    
    set_EA;
                    
    /* set T2AO1(P1.5)/T2AO2(P1.6) pin to toggling output */
    set_T2AOE1;
    set_T2AOE2;
    
    /* start Timer2A */
    set_TR2A;
  
    while(TF2A == 0);
    
    while(1);
}
